
module RegularTree where

data T a = RegularTree (M.Map Int a) Int Int

data Node a =  Int
