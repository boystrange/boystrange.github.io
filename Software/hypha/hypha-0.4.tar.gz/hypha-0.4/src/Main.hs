-- This file is part of Hypha.
--
-- Hypha is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- (at your option) any later version.
--
-- Hypha is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
--
-- You should have received a copy of the GNU General Public License
-- along with Hypha.  If not, see <http://www.gnu.org/licenses/>.
--
-- Copyright 2013-2014 Luca Padovani

module Main (main) where

import Aux
import Process
import Render
import Linearity.Use
import Linearity.Type
import Linearity.UseCombination
import Linearity.TypeCombination
import Linearity.Process

-- import qualified DeadLock.Interface
-- import qualified DeadLock.Generator
-- import qualified DeadLock.Solver
-- import qualified DeadLock.Type as DT
-- import qualified DeadLock.Level as DL
-- import qualified DeadLock.Ticket as DTic

import qualified Session.Type
import qualified Session.Decompiler

-- import qualified DeadLock2.Interface
-- import qualified DeadLock2.Generator
-- import qualified DeadLock2.Type as DT
-- import BasicType
-- import qualified DeadLock2.ValueExpression as VE
-- import qualified DeadLock2.TypeExpression as TE
-- import qualified DeadLock2.Solver

import qualified Parser
import qualified Lexer
import qualified Linearity.Generator as Generator
import qualified Relation
import Control.Monad
import System.Console.GetOpt
import System.IO
import System.Exit
import System.Environment
import Data.Set.Unicode
import Data.Bool.Unicode
import qualified Data.Set as S
import qualified Data.Map as M
import qualified Data.List as L
import qualified Linearity.UseSolver as UseSolver
import qualified Linearity.TypeSolver as TypeSolver
import qualified Linearity.Partitioner as Partitioner
import qualified Linearity.Combination as Combination
import Data.Time

import Debug.Trace

versionInfo :: String
versionInfo =
    "Hypha 0.4 - Type Reconstruction for the Linear π-Calculus\n"
    ++ "Copyright © 2013-2014 Luca Padovani\n"
    ++ "License GPLv3+: GNU GPL version 3 or later <http://gnu.org/licenses/gpl.html>.\n"
    ++ "This is free software: you are free to change and redistribute it.\n"
    ++ "There is NO WARRANTY, to the extent permitted by law."

showPRED :: (Show a) => String -> a -> String
showPRED pred x = pred ++ " " ++ show x

showREL :: (Show a, Show b) => String -> (a, b) -> String
showREL rel (x, y) = "  " ++ show x ++ " " ++ rel ++ " " ++ show y

showREL3 :: (Show a, Show b, Show c) => String -> String -> (a, b, c) -> String
showREL3 rel op (x, y, z) = "  " ++ show x ++ " " ++ rel ++ " " ++ show y ++ " " ++ op ++ " " ++ show z

showSDV :: (TypeV, (Type, Type)) -> String
showSDV (tvar, (t, s)) = "  " ++ show (TVar tvar :: Type) ++ " = " ++ show t ++ " - " ++ show s

showC :: (TypeV, S.Set TypeC) -> String
showC (tvar, tcset) = "  " ++ show (TVar tvar :: Type) ++ " = " ++ showSet tcset
    where
      showSet :: Show a => S.Set a -> String
      showSet s = L.intercalate " = " (L.map show $ S.toList s)

putSectionTitle :: String -> String -> IO ()
putSectionTitle s t = do putStrLn $ "┌─" ++ L.replicate sl '─' ++ "─┬─" ++ L.replicate tl '─' ++ "─╖"
                         putStrLn $ "│ " ++ s ++ " │ " ++ t ++ " ║"
                         putStrLn $ "╘═" ++ L.replicate sl '═' ++ "═╧═" ++ L.replicate tl '═' ++ "═╝"
  where
    sl = length s
    tl = length t
    
printUseEnvironment :: Use -> UseEnvironment -> IO ()
printUseEnvironment u env =
    do let us = map (show . UVar . fst) $ M.toList $ M.filter (== u) env
       if us /= [] then putStrLn $ "  " ++ show u ++ (concat $ map (" = " ++) us)
       else return ()

printEnvironment :: (Ord v, Show v) => (k -> String) -> M.Map k v -> IO ()
printEnvironment showKey env = forM_ im (\(v, keys) -> putStrLn $ "  " ++ show v ++ (concat $ map (\k -> " = " ++ showKey k) keys))
    where
      im = map (\v -> (v, M.keys $ M.filter (== v) env)) values

      values = L.nub $ M.elems env

printTime :: String -> UTCTime -> IO ()
printTime msg t0 =
    do t1 <- getCurrentTime
       putStrLn $ "⌚ [" ++ msg ++ ": " ++ show (diffUTCTime t1 t0) ++ "]"

reconstruction :: [Flag] -> UntypedProcess -> IO (Process Type, M.Map Name Type)
reconstruction args p =
    do timeGenerateStart <- getCurrentTime
       let (q, env, (eqm0, stm0, cot0, com0, eqU)) = Generator.generate (OddChannels `elem` args) p
       when (Verbose `elem` args)
            (do putSectionTitle "BASIC" "PROCESS"
                putStrLn $ Render.renderProcess show q
                putSectionTitle "BASIC" "UNSOLVED TYPE ENVIRONMENT"
                forM_ (M.toAscList env) (\(u, t) -> putStrLn $ "  " ++ u ++ " : " ++ show t)
                putSectionTitle "BASIC" "TYPE CONSTRAINTS"
                forM_ (map (\(tvar, t) -> (TVar tvar :: Type, t)) $ M.toList eqm0) (putStrLn . showREL "=")
                forM_ (map (\(tvar, t) -> (TVar tvar :: Type, t)) $ M.toList $ M.difference stm0 eqm0) (putStrLn . showREL "~")
                forM_ (map (\(tvar, tc) -> (TVar tvar :: Type, tc)) $ M.toList cot0) (putStrLn . showREL "=")
                putSectionTitle "BASIC" "ALL TYPE COMBINATIONS"
                forM_ (M.toList com0) (putStrLn . showC)
                putSectionTitle "BASIC" "USE CONSTRAINTS"
                forM_ (S.toList eqU) (putStrLn . showREL "=")
                when (Timing `elem` args)
                     (printTime "CONSTRAINT GENERATOR" timeGenerateStart)
            )

       timeUseSolutionStart <- getCurrentTime
       let ucS = if Partition `elem` args then Partitioner.partitionUseConstraints eqU else [eqU]
       let uenv0 = M.unions $ map (UseSolver.findUseSolution (MinUses `elem` args)) ucS
       let uvarset = (S.unions $ map Linearity.Type.fuv $ M.elems eqm0) ∪
                     (S.unions $ map Linearity.Type.fuv $ M.elems stm0)
       let uenv = M.union uenv0 $ M.fromList [(uvar, 0) | uvar <- S.toList uvarset ]

       when (Verbose `elem` args)
            (do putSectionTitle "BASIC" "USE SOLUTION"
                putStrLn $ "  [found " ++ show (S.size uvarset) ++ " use variables and "
                                       ++ show (length ucS) ++ " partition(s) of use constraints]"
                let nlargest = maximum $ map (S.size .
                                              S.unions .
                                              map (uncurry S.union) .
                                              S.elems .
                                              S.map (mapPair Linearity.UseCombination.fuv)) (S.empty : ucS)
                putStrLn $ "  [the largest partition has " ++ show nlargest ++ " use variables]"
                printUseEnvironment 0 uenv
                printUseEnvironment 1 uenv
                printUseEnvironment ω uenv
                when (Timing `elem` args)
                     (printTime "USE SOLVER" timeUseSolutionStart)
            )

       let eqm = M.map (substUT uenv) eqm0
       let stm = M.map (substUT uenv) stm0
       -- lazyness alert: if there is no solution for use constraints but there are
       -- empty combinations in front of those where the unsolvable use variables occur
       -- then the program will not signal unsatisfiability and will output a (wrong) result
       -- the following line will FORCE evaluation of all the use constraints even when
       -- hypha has been invoked without the -v option
       when (minimum (M.elems uenv) >= Zero) (return ())
       let com = M.map (Linearity.TypeCombination.substUC uenv . S.findMin) com0
       timeTypeSolutionStart <- getCurrentTime
       let defm = TypeSolver.definitions eqm stm com
       when (Verbose `elem` args)
            (do putSectionTitle "BASIC" "TYPE SOLUTION"
                forM_ (map (\(tvar, t) -> (TVar tvar :: Type, t)) $ M.toList defm) (putStrLn . showREL "↦")
                when (Timing `elem` args)
                     (do printTime "TYPE SOLVER" timeTypeSolutionStart
                         printTime "RECONSTRUCTION" timeGenerateStart)
            )

       let f = substTT defm . substUT uenv
       return (mapProcess f q, M.map f env)

{-
deadlockAnalysis :: [Flag] -> M.Map Name Type -> Process Type -> IO ()
deadlockAnalysis args env0 p0 =
    do let cost = if Lock `elem` args then 1 else 0
       let (p, env, (eql, ltl, eqt)) = DeadLock.Generator.generate (DTic.Ticket cost) $ DeadLock.Interface.processM env0 p0
       putSectionTitle "PROCESS"
       putStrLn $ Render.renderProcess show p
       putSectionTitle "UNSOLVED TYPE ENVIRONMENT"
       forM_ (M.toAscList env) (\(u, t) -> putStrLn $ "  " ++ u ++ " : " ++ show t)
       putSectionTitle "LEVEL/TICKET CONSTRAINTS"
       forM_ (S.elems eql) (putStrLn . showREL "=")
       forM_ (S.elems ltl) (putStrLn . showREL "<")
       when (Lock `elem` args) $ forM_ (S.elems eqt) (putStrLn . showREL "=")
       solution <- DeadLock.Solver.solve (Lock `elem` args) eql ltl eqt
       case solution of
         Nothing -> error "no solution for (dead)lock freedom"
         Just (lenv, tenv) ->
             do printEnvironment (show . DL.LVar) lenv
                when (Lock `elem` args) $ printEnvironment (show . DTic.TiVar) tenv
-}

sessionAnalysis :: [Flag] -> M.Map Name Type -> Process Type -> IO ()
sessionAnalysis args env p =
  do let env' = M.map (Session.Type.refold . Session.Decompiler.decompile) env
     let p' = Process.mapProcess (Session.Type.refold . Session.Decompiler.decompile) p
     putSectionTitle "SESSION" "TYPE ENVIRONMENT"
     forM_ (M.toAscList env') (putStrLn . uncurry Session.Type.showBinding)
     when (Verbose `elem` args)
          (do putSectionTitle "SESSION" "PROCESS"
              putStrLn $ Render.renderProcess show p'
          )

{-
deadlockAnalysis :: [Flag] -> M.Map Name Type -> Process Type -> IO ()
deadlockAnalysis args env0 p0 =
    do timeGeneratorStart <- getCurrentTime
       let (p, env, (eqm, stm, cor, eql, ltl, eqtic)) = DeadLock2.Generator.generate (Lock `elem` args) $
                                                        DeadLock2.Interface.processM env0 p0
       putSectionTitle "DEADLOCK" "PROCESS"
       putStrLn $ Render.renderProcess show p
       putSectionTitle "DEADLOCK" "UNSOLVED TYPE ENVIRONMENT"
       forM_ (M.toAscList env) (\(u, t) -> putStrLn $ "  " ++ u ++ " : " ++ show t)
       putSectionTitle "DEADLOCK" "TYPE CONSTRAINTS"
       forM_ (map (\(tvar, t) -> (TE.TEVar tvar VE.valueNil VE.valueNil, t)) $ M.toList eqm) (putStrLn . showREL "=")
       forM_ (map (\(tvar, t) -> (TE.TEVar tvar VE.valueNil VE.valueNil, t)) $ M.toList $ M.difference stm eqm) (putStrLn . showREL "~")
       forM_ (S.toList cor) (putStrLn . showREL3 "=" "+")
       putSectionTitle "DEADLOCK" "LEVEL CONSTRAINTS"
       forM_ (S.toList eql) (putStrLn . showREL "=")
       forM_ (S.toList ltl) (putStrLn . showREL "<")
       when (Lock `elem` args)
            (do putSectionTitle "DEADLOCK" "TICKET CONSTRAINTS"
                forM_ (S.toList eqtic) (putStrLn . showREL "=")
            )
       when (Timing `elem` args)
            (printTime "CONSTRAINT GENERATOR" timeGeneratorStart)
       timeSolverStart <- getCurrentTime
       solutionL <- DeadLock2.Solver.solve (Lock `elem` args) round eql ltl
       solutionTic <- if Lock `elem` args then DeadLock2.Solver.solve True round eqtic S.empty else return Nothing
       putSectionTitle "DEADLOCK" "PROCESS 2"
       putStrLn $ Render.renderProcess show (Process.mapProcess (TE.approximate . TE.findD eqm) p)
       case solutionL of
         Nothing -> error "no solution for (dead)lock freedom"
         Just lenv ->
           when (Verbose `elem` args)
                (do putSectionTitle "DEADLOCK" "LEVEL SOLUTION"
                    printEnvironment show lenv
                    when (Timing `elem` args)
                         (printTime "LEVEL SOLVER" timeSolverStart)
                )
       when (Lock `elem` args)
            (do case solutionTic of
                  Nothing -> error "no solution for lock freedom"
                  Just ticenv ->
                    when (Verbose `elem` args)
                         (do putSectionTitle "LOCK" "TICKET SOLUTION"
                             printEnvironment show ticenv
                         )
             )
-}

main :: IO ()
main = do
  (args, file) <- getArgs >>= parse
  source <- if file == "-" then getContents else readFile file
  let p = Parser.process $ Lexer.alexScanTokens source

  timeProcessStart <- getCurrentTime
  (q1, env1) <- reconstruction args p
  putSectionTitle "BASIC" "TYPE ENVIRONMENT"
  forM_ (M.toAscList env1) (\(u, t) -> putStrLn $ "  " ++ u ++ " : " ++ show t)

  when (Session `elem` args) $ sessionAnalysis args env1 q1
  
  -- when (DeadLock `elem` args ∨ Lock `elem` args) $ deadlockAnalysis args env1 q1

  timeProcessEnd <- getCurrentTime
  when (Timing `elem` args)
       (hPutStrLn stderr $ show (diffUTCTime timeProcessEnd timeProcessStart) ++ " for processing " ++ file)

data Flag = Partition   --    --partition
          | OddChannels -- -o --odd-channels
          | MinUses     -- -m --minimum-uses
          | Timing      --    --timing
          | Verbose     -- -v --verbose
          | Version     -- -V --version
          | Session     -- -s
          -- | DeadLock    -- -d
          -- | Lock        -- -l
          | Help        --    --help
            deriving (Eq,Ord,Enum,Show,Bounded)
 
flags =
   [Option ""  ["partition"]      (NoArg Partition)   "Partition use constraints",
    Option "o" ["odd-channels"]   (NoArg OddChannels) "Allow different input/output uses for restricted channels",
    Option "m" ["minimum-uses"]   (NoArg MinUses)     "Minimize the number of ωs in uses",
    Option "s" []                 (NoArg Session)     "Enable session analysis",
    -- Option "d" []                 (NoArg DeadLock)    "Enable deadlock freedom analysis",
    -- Option "l" []                 (NoArg Lock)        "Enable lock freedom analysis", 
    Option ""  ["timing"]         (NoArg Timing)      "Show timing",
    Option "v" ["verbose"]        (NoArg Verbose)     "Print use and type constraints",
    Option "V" ["version"]        (NoArg Version)     "Print version information",
    Option "h" ["help"]           (NoArg Help)        "Print this help message"
   ]

parse argv =
    case getOpt Permute flags argv of
      (args, files, []) -> do
        when (Version `elem` args)
             (do hPutStrLn stderr versionInfo
                 exitWith ExitSuccess)
        when (null files || L.length files > 1 || Help `elem` args)
                 (do hPutStrLn stderr (usageInfo header flags)
                     exitWith ExitSuccess)
        return (args, head files)
 
      (_, _, errs) -> do
        hPutStrLn stderr (concat errs ++ usageInfo header flags)
        exitWith (ExitFailure 1)
 
    where
      header = "Usage: hypha [options] FILE"
