-- This file is part of Hypha.
--
-- Hypha is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- (at your option) any later version.
--
-- Hypha is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
--
-- You should have received a copy of the GNU General Public License
-- along with Hypha.  If not, see <http://www.gnu.org/licenses/>.
--
-- Copyright 2013 Luca Padovani

module Process where

import qualified Data.Set as S
import Data.Set.Unicode

type Tag = String
type Name = String

type Rule t = (Tag, Name, t, Process t)

data Process t =
    Idle
  | Send (Expression t) (Expression t) (Process t)
  | Receive (Expression t) Name t (Process t)
  | Star (Process t)
  | Par (Process t) (Process t)
  | New Name t (Process t)
  | Group (Process t)
  | Let Name t (Expression t) (Process t)
  | Split (Expression t) Name t Name t (Process t)
  | If (Expression t) (Process t) (Process t)
  | Case (Expression t) [Rule t]

data Const =
    UNIT
  | INT Int
  | BOOL Bool
    deriving Eq

data UnOp =
    NOT
  | FST
  | SND

data BinOp =
    AND
  | OR
  | LT
  | LE
  | GT
  | GE
  | EQ
  | NE
  | ADD
  | SUB
  | MUL
  | DIV
  | MOD
  | PAIR
    deriving Eq

data Expression t =
    Id Name t
  | Const Const
  | UnOp UnOp (Expression t)
  | BinOp BinOp (Expression t) (Expression t)
  | Tag Tag (Expression t)

mapProcess :: (t -> t') -> Process t -> Process t'
mapProcess m = auxP
    where
      auxP Idle = Idle
      auxP (Send e f p) = Send (auxE e) (auxE f) (auxP p)
      auxP (Receive e x typ p) = Receive (auxE e) x (m typ) (auxP p)
      auxP (Star p) = Star (auxP p)
      auxP (Par p q) = Par (auxP p) (auxP q)
      auxP (New x typ p) = New x (m typ) (auxP p)
      auxP (Group p) = Group (auxP p)
      auxP (Let x typ e p) = Let x (m typ) (auxE e) (auxP p)
      auxP (Split e x xt y yt p) = Split (auxE e) x (m xt) y (m yt) (auxP p)
      auxP (If e p q) = If (auxE e) (auxP p) (auxP q)
      auxP (Case e rules) = Case (auxE e) (map auxR rules)

      auxE (Id x typ) = Id x (m typ)
      auxE (Const c) = Const c
      auxE (UnOp op e) = UnOp (auxUO op) (auxE e)
      auxE (BinOp op e1 e2) = BinOp op (auxE e1) (auxE e2)
      auxE (Tag tag e) = Tag tag (auxE e)

      auxUO NOT = NOT
      auxUO FST = FST
      auxUO SND = SND

      auxR (tag, x, typ, p) = (tag, x, (m typ), auxP p)

fn :: Process t -> S.Set Name
fn = auxP
    where
      auxP Idle = (∅)
      auxP (Send e1 e2 p) = auxE e1 ∪ auxE e2 ∪ auxP p
      auxP (Receive e x _ p) = auxE e ∪ (S.delete x $ auxP p)
      auxP (Star p) = auxP p
      auxP (Par p q) = auxP p ∪ auxP q
      auxP (New x _ p) = S.delete x $ auxP p
      auxP (Group p) = auxP p
      auxP (Let x _ e p) = auxE e ∪ (S.delete x $ auxP p)
      auxP (Split e x _ y _ p) = auxE e ∪ (S.delete x $ S.delete y $ auxP p)
      auxP (If e p q) = auxE e ∪ auxP p ∪ auxP q
      auxP (Case e rules) = auxE e ∪ S.unions (map auxR rules)

      auxE (Id x _) = S.singleton x
      auxE (Const _) = S.empty
      auxE (UnOp _ e) = auxE e
      auxE (BinOp _ e1 e2) = auxE e1 ∪ auxE e2
      auxE (Tag _ e) = auxE e

      auxR (_, x, _, p) = S.delete x $ auxP p
