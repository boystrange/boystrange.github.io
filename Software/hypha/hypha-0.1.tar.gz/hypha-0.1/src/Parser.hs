{-# OPTIONS_GHC -w #-}
module Parser where

import Lexer
import Process

-- parser produced by Happy Version 1.18.9

data HappyAbsSyn t4 t5 t6 t7 t8 t9
	= HappyTerminal (Token)
	| HappyErrorToken Int
	| HappyAbsSyn4 t4
	| HappyAbsSyn5 t5
	| HappyAbsSyn6 t6
	| HappyAbsSyn7 t7
	| HappyAbsSyn8 t8
	| HappyAbsSyn9 t9

action_0 (10) = happyShift action_4
action_0 (14) = happyShift action_5
action_0 (15) = happyShift action_6
action_0 (19) = happyShift action_7
action_0 (21) = happyShift action_8
action_0 (39) = happyShift action_9
action_0 (46) = happyShift action_10
action_0 (4) = happyGoto action_3
action_0 _ = happyFail

action_1 (14) = happyShift action_2
action_1 _ = happyFail

action_2 (41) = happyShift action_28
action_2 _ = happyFail

action_3 (26) = happyShift action_31
action_3 (51) = happyAccept
action_3 _ = happyFail

action_4 (14) = happyShift action_30
action_4 _ = happyFail

action_5 (41) = happyShift action_28
action_5 (42) = happyShift action_29
action_5 _ = happyFail

action_6 (14) = happyShift action_25
action_6 (27) = happyShift action_26
action_6 (50) = happyShift action_27
action_6 (8) = happyGoto action_24
action_6 _ = happyFail

action_7 (11) = happyShift action_15
action_7 (12) = happyShift action_16
action_7 (13) = happyShift action_17
action_7 (14) = happyShift action_18
action_7 (17) = happyShift action_19
action_7 (18) = happyShift action_20
action_7 (27) = happyShift action_21
action_7 (36) = happyShift action_22
action_7 (9) = happyGoto action_23
action_7 _ = happyFail

action_8 (11) = happyShift action_15
action_8 (12) = happyShift action_16
action_8 (13) = happyShift action_17
action_8 (14) = happyShift action_18
action_8 (17) = happyShift action_19
action_8 (18) = happyShift action_20
action_8 (27) = happyShift action_21
action_8 (36) = happyShift action_22
action_8 (9) = happyGoto action_14
action_8 _ = happyFail

action_9 (10) = happyShift action_4
action_9 (14) = happyShift action_5
action_9 (15) = happyShift action_6
action_9 (19) = happyShift action_7
action_9 (21) = happyShift action_8
action_9 (39) = happyShift action_9
action_9 (46) = happyShift action_10
action_9 (4) = happyGoto action_12
action_9 (6) = happyGoto action_13
action_9 _ = happyReduce_12

action_10 (10) = happyShift action_4
action_10 (14) = happyShift action_5
action_10 (15) = happyShift action_6
action_10 (19) = happyShift action_7
action_10 (21) = happyShift action_8
action_10 (39) = happyShift action_9
action_10 (46) = happyShift action_10
action_10 (4) = happyGoto action_11
action_10 _ = happyFail

action_11 _ = happyReduce_9

action_12 (26) = happyShift action_31
action_12 _ = happyReduce_13

action_13 (40) = happyShift action_59
action_13 _ = happyFail

action_14 (22) = happyShift action_58
action_14 (25) = happyShift action_40
action_14 (29) = happyShift action_41
action_14 (30) = happyShift action_42
action_14 (31) = happyShift action_43
action_14 (32) = happyShift action_44
action_14 (33) = happyShift action_45
action_14 (34) = happyShift action_46
action_14 (35) = happyShift action_47
action_14 (43) = happyShift action_48
action_14 (46) = happyShift action_49
action_14 (47) = happyShift action_50
action_14 (48) = happyShift action_51
action_14 (49) = happyShift action_52
action_14 _ = happyFail

action_15 _ = happyReduce_21

action_16 _ = happyReduce_22

action_17 _ = happyReduce_23

action_18 _ = happyReduce_24

action_19 (11) = happyShift action_15
action_19 (12) = happyShift action_16
action_19 (13) = happyShift action_17
action_19 (14) = happyShift action_18
action_19 (17) = happyShift action_19
action_19 (18) = happyShift action_20
action_19 (27) = happyShift action_21
action_19 (36) = happyShift action_22
action_19 (9) = happyGoto action_57
action_19 _ = happyFail

action_20 (11) = happyShift action_15
action_20 (12) = happyShift action_16
action_20 (13) = happyShift action_17
action_20 (14) = happyShift action_18
action_20 (17) = happyShift action_19
action_20 (18) = happyShift action_20
action_20 (27) = happyShift action_21
action_20 (36) = happyShift action_22
action_20 (9) = happyGoto action_56
action_20 _ = happyFail

action_21 (11) = happyShift action_15
action_21 (12) = happyShift action_16
action_21 (13) = happyShift action_17
action_21 (14) = happyShift action_18
action_21 (17) = happyShift action_19
action_21 (18) = happyShift action_20
action_21 (27) = happyShift action_21
action_21 (28) = happyShift action_55
action_21 (36) = happyShift action_22
action_21 (9) = happyGoto action_54
action_21 _ = happyFail

action_22 (11) = happyShift action_15
action_22 (12) = happyShift action_16
action_22 (13) = happyShift action_17
action_22 (14) = happyShift action_18
action_22 (17) = happyShift action_19
action_22 (18) = happyShift action_20
action_22 (27) = happyShift action_21
action_22 (36) = happyShift action_22
action_22 (9) = happyGoto action_53
action_22 _ = happyFail

action_23 (20) = happyShift action_39
action_23 (25) = happyShift action_40
action_23 (29) = happyShift action_41
action_23 (30) = happyShift action_42
action_23 (31) = happyShift action_43
action_23 (32) = happyShift action_44
action_23 (33) = happyShift action_45
action_23 (34) = happyShift action_46
action_23 (35) = happyShift action_47
action_23 (43) = happyShift action_48
action_23 (46) = happyShift action_49
action_23 (47) = happyShift action_50
action_23 (48) = happyShift action_51
action_23 (49) = happyShift action_52
action_23 _ = happyFail

action_24 (25) = happyShift action_37
action_24 (43) = happyShift action_38
action_24 _ = happyFail

action_25 _ = happyReduce_17

action_26 (14) = happyShift action_25
action_26 (27) = happyShift action_26
action_26 (50) = happyShift action_27
action_26 (8) = happyGoto action_36
action_26 _ = happyFail

action_27 _ = happyReduce_16

action_28 (11) = happyShift action_15
action_28 (12) = happyShift action_16
action_28 (13) = happyShift action_17
action_28 (14) = happyShift action_18
action_28 (17) = happyShift action_19
action_28 (18) = happyShift action_20
action_28 (27) = happyShift action_21
action_28 (36) = happyShift action_22
action_28 (9) = happyGoto action_35
action_28 _ = happyFail

action_29 (27) = happyShift action_34
action_29 _ = happyFail

action_30 (16) = happyShift action_33
action_30 _ = happyFail

action_31 (10) = happyShift action_4
action_31 (14) = happyShift action_5
action_31 (15) = happyShift action_6
action_31 (19) = happyShift action_7
action_31 (21) = happyShift action_8
action_31 (39) = happyShift action_9
action_31 (46) = happyShift action_10
action_31 (4) = happyGoto action_32
action_31 _ = happyFail

action_32 _ = happyReduce_6

action_33 (10) = happyShift action_4
action_33 (14) = happyShift action_5
action_33 (15) = happyShift action_6
action_33 (19) = happyShift action_7
action_33 (21) = happyShift action_8
action_33 (39) = happyShift action_9
action_33 (46) = happyShift action_10
action_33 (4) = happyGoto action_81
action_33 _ = happyFail

action_34 (14) = happyShift action_25
action_34 (27) = happyShift action_26
action_34 (50) = happyShift action_27
action_34 (7) = happyGoto action_79
action_34 (8) = happyGoto action_80
action_34 _ = happyReduce_14

action_35 (25) = happyShift action_40
action_35 (29) = happyShift action_41
action_35 (30) = happyShift action_42
action_35 (31) = happyShift action_43
action_35 (32) = happyShift action_44
action_35 (33) = happyShift action_45
action_35 (34) = happyShift action_46
action_35 (35) = happyShift action_47
action_35 (43) = happyShift action_48
action_35 (46) = happyShift action_49
action_35 (47) = happyShift action_50
action_35 (48) = happyShift action_51
action_35 (49) = happyShift action_52
action_35 _ = happyReduce_1

action_36 (28) = happyShift action_78
action_36 (43) = happyShift action_38
action_36 _ = happyFail

action_37 (11) = happyShift action_15
action_37 (12) = happyShift action_16
action_37 (13) = happyShift action_17
action_37 (14) = happyShift action_18
action_37 (17) = happyShift action_19
action_37 (18) = happyShift action_20
action_37 (27) = happyShift action_21
action_37 (36) = happyShift action_22
action_37 (9) = happyGoto action_77
action_37 _ = happyFail

action_38 (14) = happyShift action_25
action_38 (27) = happyShift action_26
action_38 (50) = happyShift action_27
action_38 (8) = happyGoto action_76
action_38 _ = happyFail

action_39 (37) = happyShift action_75
action_39 _ = happyFail

action_40 (11) = happyShift action_15
action_40 (12) = happyShift action_16
action_40 (13) = happyShift action_17
action_40 (14) = happyShift action_18
action_40 (17) = happyShift action_19
action_40 (18) = happyShift action_20
action_40 (27) = happyShift action_21
action_40 (36) = happyShift action_22
action_40 (9) = happyGoto action_74
action_40 _ = happyFail

action_41 (11) = happyShift action_15
action_41 (12) = happyShift action_16
action_41 (13) = happyShift action_17
action_41 (14) = happyShift action_18
action_41 (17) = happyShift action_19
action_41 (18) = happyShift action_20
action_41 (27) = happyShift action_21
action_41 (36) = happyShift action_22
action_41 (9) = happyGoto action_73
action_41 _ = happyFail

action_42 (11) = happyShift action_15
action_42 (12) = happyShift action_16
action_42 (13) = happyShift action_17
action_42 (14) = happyShift action_18
action_42 (17) = happyShift action_19
action_42 (18) = happyShift action_20
action_42 (27) = happyShift action_21
action_42 (36) = happyShift action_22
action_42 (9) = happyGoto action_72
action_42 _ = happyFail

action_43 (11) = happyShift action_15
action_43 (12) = happyShift action_16
action_43 (13) = happyShift action_17
action_43 (14) = happyShift action_18
action_43 (17) = happyShift action_19
action_43 (18) = happyShift action_20
action_43 (27) = happyShift action_21
action_43 (36) = happyShift action_22
action_43 (9) = happyGoto action_71
action_43 _ = happyFail

action_44 (11) = happyShift action_15
action_44 (12) = happyShift action_16
action_44 (13) = happyShift action_17
action_44 (14) = happyShift action_18
action_44 (17) = happyShift action_19
action_44 (18) = happyShift action_20
action_44 (27) = happyShift action_21
action_44 (36) = happyShift action_22
action_44 (9) = happyGoto action_70
action_44 _ = happyFail

action_45 (11) = happyShift action_15
action_45 (12) = happyShift action_16
action_45 (13) = happyShift action_17
action_45 (14) = happyShift action_18
action_45 (17) = happyShift action_19
action_45 (18) = happyShift action_20
action_45 (27) = happyShift action_21
action_45 (36) = happyShift action_22
action_45 (9) = happyGoto action_69
action_45 _ = happyFail

action_46 (11) = happyShift action_15
action_46 (12) = happyShift action_16
action_46 (13) = happyShift action_17
action_46 (14) = happyShift action_18
action_46 (17) = happyShift action_19
action_46 (18) = happyShift action_20
action_46 (27) = happyShift action_21
action_46 (36) = happyShift action_22
action_46 (9) = happyGoto action_68
action_46 _ = happyFail

action_47 (11) = happyShift action_15
action_47 (12) = happyShift action_16
action_47 (13) = happyShift action_17
action_47 (14) = happyShift action_18
action_47 (17) = happyShift action_19
action_47 (18) = happyShift action_20
action_47 (27) = happyShift action_21
action_47 (36) = happyShift action_22
action_47 (9) = happyGoto action_67
action_47 _ = happyFail

action_48 (11) = happyShift action_15
action_48 (12) = happyShift action_16
action_48 (13) = happyShift action_17
action_48 (14) = happyShift action_18
action_48 (17) = happyShift action_19
action_48 (18) = happyShift action_20
action_48 (27) = happyShift action_21
action_48 (36) = happyShift action_22
action_48 (9) = happyGoto action_66
action_48 _ = happyFail

action_49 (11) = happyShift action_15
action_49 (12) = happyShift action_16
action_49 (13) = happyShift action_17
action_49 (14) = happyShift action_18
action_49 (17) = happyShift action_19
action_49 (18) = happyShift action_20
action_49 (27) = happyShift action_21
action_49 (36) = happyShift action_22
action_49 (9) = happyGoto action_65
action_49 _ = happyFail

action_50 (11) = happyShift action_15
action_50 (12) = happyShift action_16
action_50 (13) = happyShift action_17
action_50 (14) = happyShift action_18
action_50 (17) = happyShift action_19
action_50 (18) = happyShift action_20
action_50 (27) = happyShift action_21
action_50 (36) = happyShift action_22
action_50 (9) = happyGoto action_64
action_50 _ = happyFail

action_51 (11) = happyShift action_15
action_51 (12) = happyShift action_16
action_51 (13) = happyShift action_17
action_51 (14) = happyShift action_18
action_51 (17) = happyShift action_19
action_51 (18) = happyShift action_20
action_51 (27) = happyShift action_21
action_51 (36) = happyShift action_22
action_51 (9) = happyGoto action_63
action_51 _ = happyFail

action_52 (11) = happyShift action_15
action_52 (12) = happyShift action_16
action_52 (13) = happyShift action_17
action_52 (14) = happyShift action_18
action_52 (17) = happyShift action_19
action_52 (18) = happyShift action_20
action_52 (27) = happyShift action_21
action_52 (36) = happyShift action_22
action_52 (9) = happyGoto action_62
action_52 _ = happyFail

action_53 _ = happyReduce_33

action_54 (25) = happyShift action_40
action_54 (28) = happyShift action_61
action_54 (29) = happyShift action_41
action_54 (30) = happyShift action_42
action_54 (31) = happyShift action_43
action_54 (32) = happyShift action_44
action_54 (33) = happyShift action_45
action_54 (34) = happyShift action_46
action_54 (35) = happyShift action_47
action_54 (43) = happyShift action_48
action_54 (46) = happyShift action_49
action_54 (47) = happyShift action_50
action_54 (48) = happyShift action_51
action_54 (49) = happyShift action_52
action_54 _ = happyFail

action_55 _ = happyReduce_20

action_56 (25) = happyShift action_40
action_56 (29) = happyShift action_41
action_56 (30) = happyShift action_42
action_56 (31) = happyShift action_43
action_56 (32) = happyShift action_44
action_56 (33) = happyShift action_45
action_56 (34) = happyShift action_46
action_56 (35) = happyShift action_47
action_56 (46) = happyShift action_49
action_56 (47) = happyShift action_50
action_56 (48) = happyShift action_51
action_56 (49) = happyShift action_52
action_56 _ = happyReduce_39

action_57 (25) = happyShift action_40
action_57 (29) = happyShift action_41
action_57 (30) = happyShift action_42
action_57 (31) = happyShift action_43
action_57 (32) = happyShift action_44
action_57 (33) = happyShift action_45
action_57 (34) = happyShift action_46
action_57 (35) = happyShift action_47
action_57 (46) = happyShift action_49
action_57 (47) = happyShift action_50
action_57 (48) = happyShift action_51
action_57 (49) = happyShift action_52
action_57 _ = happyReduce_38

action_58 (10) = happyShift action_4
action_58 (14) = happyShift action_5
action_58 (15) = happyShift action_6
action_58 (19) = happyShift action_7
action_58 (21) = happyShift action_8
action_58 (39) = happyShift action_9
action_58 (46) = happyShift action_10
action_58 (4) = happyGoto action_60
action_58 _ = happyFail

action_59 _ = happyReduce_8

action_60 (23) = happyShift action_85
action_60 (26) = happyShift action_31
action_60 _ = happyFail

action_61 _ = happyReduce_40

action_62 _ = happyReduce_37

action_63 (46) = happyShift action_49
action_63 (49) = happyShift action_52
action_63 _ = happyReduce_35

action_64 (46) = happyShift action_49
action_64 (49) = happyShift action_52
action_64 _ = happyReduce_34

action_65 _ = happyReduce_36

action_66 (25) = happyShift action_40
action_66 (29) = happyShift action_41
action_66 (30) = happyShift action_42
action_66 (31) = happyShift action_43
action_66 (32) = happyShift action_44
action_66 (33) = happyShift action_45
action_66 (34) = happyShift action_46
action_66 (35) = happyShift action_47
action_66 (43) = happyShift action_48
action_66 (46) = happyShift action_49
action_66 (47) = happyShift action_50
action_66 (48) = happyShift action_51
action_66 (49) = happyShift action_52
action_66 _ = happyReduce_41

action_67 (25) = happyShift action_40
action_67 (29) = happyShift action_41
action_67 (30) = happyShift action_42
action_67 (31) = happyShift action_43
action_67 (32) = happyShift action_44
action_67 (33) = happyShift action_45
action_67 (46) = happyShift action_49
action_67 (47) = happyShift action_50
action_67 (48) = happyShift action_51
action_67 (49) = happyShift action_52
action_67 _ = happyReduce_26

action_68 (25) = happyShift action_40
action_68 (29) = happyShift action_41
action_68 (30) = happyShift action_42
action_68 (31) = happyShift action_43
action_68 (32) = happyShift action_44
action_68 (33) = happyShift action_45
action_68 (46) = happyShift action_49
action_68 (47) = happyShift action_50
action_68 (48) = happyShift action_51
action_68 (49) = happyShift action_52
action_68 _ = happyReduce_25

action_69 (25) = happyFail
action_69 (29) = happyFail
action_69 (30) = happyFail
action_69 (31) = happyFail
action_69 (32) = happyFail
action_69 (33) = happyFail
action_69 (46) = happyShift action_49
action_69 (47) = happyShift action_50
action_69 (48) = happyShift action_51
action_69 (49) = happyShift action_52
action_69 _ = happyReduce_32

action_70 (25) = happyFail
action_70 (29) = happyFail
action_70 (30) = happyFail
action_70 (31) = happyFail
action_70 (32) = happyFail
action_70 (33) = happyFail
action_70 (46) = happyShift action_49
action_70 (47) = happyShift action_50
action_70 (48) = happyShift action_51
action_70 (49) = happyShift action_52
action_70 _ = happyReduce_31

action_71 (25) = happyFail
action_71 (29) = happyFail
action_71 (30) = happyFail
action_71 (31) = happyFail
action_71 (32) = happyFail
action_71 (33) = happyFail
action_71 (46) = happyShift action_49
action_71 (47) = happyShift action_50
action_71 (48) = happyShift action_51
action_71 (49) = happyShift action_52
action_71 _ = happyReduce_30

action_72 (25) = happyFail
action_72 (29) = happyFail
action_72 (30) = happyFail
action_72 (31) = happyFail
action_72 (32) = happyFail
action_72 (33) = happyFail
action_72 (46) = happyShift action_49
action_72 (47) = happyShift action_50
action_72 (48) = happyShift action_51
action_72 (49) = happyShift action_52
action_72 _ = happyReduce_28

action_73 (25) = happyFail
action_73 (29) = happyFail
action_73 (30) = happyFail
action_73 (31) = happyFail
action_73 (32) = happyFail
action_73 (33) = happyFail
action_73 (46) = happyShift action_49
action_73 (47) = happyShift action_50
action_73 (48) = happyShift action_51
action_73 (49) = happyShift action_52
action_73 _ = happyReduce_27

action_74 (25) = happyFail
action_74 (29) = happyFail
action_74 (30) = happyFail
action_74 (31) = happyFail
action_74 (32) = happyFail
action_74 (33) = happyFail
action_74 (46) = happyShift action_49
action_74 (47) = happyShift action_50
action_74 (48) = happyShift action_51
action_74 (49) = happyShift action_52
action_74 _ = happyReduce_29

action_75 (14) = happyShift action_25
action_75 (27) = happyShift action_26
action_75 (50) = happyShift action_27
action_75 (8) = happyGoto action_84
action_75 _ = happyFail

action_76 (43) = happyShift action_38
action_76 _ = happyReduce_18

action_77 (16) = happyShift action_83
action_77 (25) = happyShift action_40
action_77 (29) = happyShift action_41
action_77 (30) = happyShift action_42
action_77 (31) = happyShift action_43
action_77 (32) = happyShift action_44
action_77 (33) = happyShift action_45
action_77 (34) = happyShift action_46
action_77 (35) = happyShift action_47
action_77 (43) = happyShift action_48
action_77 (46) = happyShift action_49
action_77 (47) = happyShift action_50
action_77 (48) = happyShift action_51
action_77 (49) = happyShift action_52
action_77 _ = happyFail

action_78 _ = happyReduce_19

action_79 (28) = happyShift action_82
action_79 _ = happyFail

action_80 (43) = happyShift action_38
action_80 _ = happyReduce_15

action_81 _ = happyReduce_7

action_82 (44) = happyShift action_90
action_82 (5) = happyGoto action_89
action_82 _ = happyReduce_10

action_83 (10) = happyShift action_4
action_83 (14) = happyShift action_5
action_83 (15) = happyShift action_6
action_83 (19) = happyShift action_7
action_83 (21) = happyShift action_8
action_83 (39) = happyShift action_9
action_83 (46) = happyShift action_10
action_83 (4) = happyGoto action_88
action_83 _ = happyFail

action_84 (24) = happyShift action_87
action_84 (43) = happyShift action_38
action_84 _ = happyFail

action_85 (10) = happyShift action_4
action_85 (14) = happyShift action_5
action_85 (15) = happyShift action_6
action_85 (19) = happyShift action_7
action_85 (21) = happyShift action_8
action_85 (39) = happyShift action_9
action_85 (46) = happyShift action_10
action_85 (4) = happyGoto action_86
action_85 _ = happyFail

action_86 (26) = happyShift action_31
action_86 _ = happyReduce_5

action_87 (10) = happyShift action_4
action_87 (14) = happyShift action_5
action_87 (15) = happyShift action_6
action_87 (19) = happyShift action_7
action_87 (21) = happyShift action_8
action_87 (39) = happyShift action_9
action_87 (46) = happyShift action_10
action_87 (4) = happyGoto action_92
action_87 _ = happyFail

action_88 _ = happyReduce_3

action_89 _ = happyReduce_2

action_90 (10) = happyShift action_4
action_90 (14) = happyShift action_5
action_90 (15) = happyShift action_6
action_90 (19) = happyShift action_7
action_90 (21) = happyShift action_8
action_90 (39) = happyShift action_9
action_90 (46) = happyShift action_10
action_90 (4) = happyGoto action_91
action_90 _ = happyFail

action_91 _ = happyReduce_11

action_92 (26) = happyShift action_93
action_92 _ = happyFail

action_93 (10) = happyShift action_4
action_93 (14) = happyShift action_95
action_93 (15) = happyShift action_6
action_93 (19) = happyShift action_7
action_93 (21) = happyShift action_8
action_93 (27) = happyShift action_26
action_93 (39) = happyShift action_9
action_93 (46) = happyShift action_10
action_93 (50) = happyShift action_27
action_93 (4) = happyGoto action_32
action_93 (8) = happyGoto action_94
action_93 _ = happyFail

action_94 (24) = happyShift action_96
action_94 (43) = happyShift action_38
action_94 _ = happyFail

action_95 (41) = happyShift action_28
action_95 (42) = happyShift action_29
action_95 _ = happyReduce_17

action_96 (10) = happyShift action_4
action_96 (14) = happyShift action_5
action_96 (15) = happyShift action_6
action_96 (19) = happyShift action_7
action_96 (21) = happyShift action_8
action_96 (39) = happyShift action_9
action_96 (46) = happyShift action_10
action_96 (4) = happyGoto action_97
action_96 _ = happyFail

action_97 (26) = happyShift action_31
action_97 (38) = happyShift action_98
action_97 _ = happyFail

action_98 _ = happyReduce_4

happyReduce_1 = happySpecReduce_3  4 happyReduction_1
happyReduction_1 (HappyAbsSyn9  happy_var_3)
	_
	(HappyTerminal (ID happy_var_1))
	 =  HappyAbsSyn4
		 (Send happy_var_1 happy_var_3
	)
happyReduction_1 _ _ _  = notHappyAtAll 

happyReduce_2 = happyReduce 6 4 happyReduction_2
happyReduction_2 ((HappyAbsSyn5  happy_var_6) `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn7  happy_var_4) `HappyStk`
	_ `HappyStk`
	_ `HappyStk`
	(HappyTerminal (ID happy_var_1)) `HappyStk`
	happyRest)
	 = HappyAbsSyn4
		 (expandReceive happy_var_1 happy_var_4 happy_var_6
	) `HappyStk` happyRest

happyReduce_3 = happyReduce 6 4 happyReduction_3
happyReduction_3 ((HappyAbsSyn4  happy_var_6) `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn9  happy_var_4) `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn8  happy_var_2) `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn4
		 (expandLet happy_var_2 happy_var_4 happy_var_6
	) `HappyStk` happyRest

happyReduce_4 = happyReduce 12 4 happyReduction_4
happyReduction_4 (_ `HappyStk`
	(HappyAbsSyn4  happy_var_11) `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn8  happy_var_9) `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn4  happy_var_7) `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn8  happy_var_5) `HappyStk`
	_ `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn9  happy_var_2) `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn4
		 (let (x1, p1) = expandCase happy_var_5 happy_var_7 in
	  let (x2, p2) = expandCase happy_var_9 happy_var_11 in
	  Case happy_var_2 x1 () p1 x2 () p2
	) `HappyStk` happyRest

happyReduce_5 = happyReduce 6 4 happyReduction_5
happyReduction_5 ((HappyAbsSyn4  happy_var_6) `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn4  happy_var_4) `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn9  happy_var_2) `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn4
		 (Case happy_var_2 "_" () happy_var_4 "_" () happy_var_6
	) `HappyStk` happyRest

happyReduce_6 = happySpecReduce_3  4 happyReduction_6
happyReduction_6 (HappyAbsSyn4  happy_var_3)
	_
	(HappyAbsSyn4  happy_var_1)
	 =  HappyAbsSyn4
		 (Par happy_var_1 happy_var_3
	)
happyReduction_6 _ _ _  = notHappyAtAll 

happyReduce_7 = happyReduce 4 4 happyReduction_7
happyReduction_7 ((HappyAbsSyn4  happy_var_4) `HappyStk`
	_ `HappyStk`
	(HappyTerminal (ID happy_var_2)) `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn4
		 (New happy_var_2 () happy_var_4
	) `HappyStk` happyRest

happyReduce_8 = happySpecReduce_3  4 happyReduction_8
happyReduction_8 _
	(HappyAbsSyn6  happy_var_2)
	_
	 =  HappyAbsSyn4
		 (Group happy_var_2
	)
happyReduction_8 _ _ _  = notHappyAtAll 

happyReduce_9 = happySpecReduce_2  4 happyReduction_9
happyReduction_9 (HappyAbsSyn4  happy_var_2)
	_
	 =  HappyAbsSyn4
		 (Star happy_var_2
	)
happyReduction_9 _ _  = notHappyAtAll 

happyReduce_10 = happySpecReduce_0  5 happyReduction_10
happyReduction_10  =  HappyAbsSyn5
		 (Idle
	)

happyReduce_11 = happySpecReduce_2  5 happyReduction_11
happyReduction_11 (HappyAbsSyn4  happy_var_2)
	_
	 =  HappyAbsSyn5
		 (happy_var_2
	)
happyReduction_11 _ _  = notHappyAtAll 

happyReduce_12 = happySpecReduce_0  6 happyReduction_12
happyReduction_12  =  HappyAbsSyn6
		 (Idle
	)

happyReduce_13 = happySpecReduce_1  6 happyReduction_13
happyReduction_13 (HappyAbsSyn4  happy_var_1)
	 =  HappyAbsSyn6
		 (happy_var_1
	)
happyReduction_13 _  = notHappyAtAll 

happyReduce_14 = happySpecReduce_0  7 happyReduction_14
happyReduction_14  =  HappyAbsSyn7
		 (PVar "_"
	)

happyReduce_15 = happySpecReduce_1  7 happyReduction_15
happyReduction_15 (HappyAbsSyn8  happy_var_1)
	 =  HappyAbsSyn7
		 (happy_var_1
	)
happyReduction_15 _  = notHappyAtAll 

happyReduce_16 = happySpecReduce_1  8 happyReduction_16
happyReduction_16 _
	 =  HappyAbsSyn8
		 (PVar "_"
	)

happyReduce_17 = happySpecReduce_1  8 happyReduction_17
happyReduction_17 (HappyTerminal (ID happy_var_1))
	 =  HappyAbsSyn8
		 (PVar happy_var_1
	)
happyReduction_17 _  = notHappyAtAll 

happyReduce_18 = happySpecReduce_3  8 happyReduction_18
happyReduction_18 (HappyAbsSyn8  happy_var_3)
	_
	(HappyAbsSyn8  happy_var_1)
	 =  HappyAbsSyn8
		 (PPair happy_var_1 happy_var_3
	)
happyReduction_18 _ _ _  = notHappyAtAll 

happyReduce_19 = happySpecReduce_3  8 happyReduction_19
happyReduction_19 _
	(HappyAbsSyn8  happy_var_2)
	_
	 =  HappyAbsSyn8
		 (happy_var_2
	)
happyReduction_19 _ _ _  = notHappyAtAll 

happyReduce_20 = happySpecReduce_2  9 happyReduction_20
happyReduction_20 _
	_
	 =  HappyAbsSyn9
		 (UNIT
	)

happyReduce_21 = happySpecReduce_1  9 happyReduction_21
happyReduction_21 (HappyTerminal (Lexer.INT happy_var_1))
	 =  HappyAbsSyn9
		 (Process.INT happy_var_1
	)
happyReduction_21 _  = notHappyAtAll 

happyReduce_22 = happySpecReduce_1  9 happyReduction_22
happyReduction_22 _
	 =  HappyAbsSyn9
		 (Process.Left UNIT
	)

happyReduce_23 = happySpecReduce_1  9 happyReduction_23
happyReduction_23 _
	 =  HappyAbsSyn9
		 (Process.Right UNIT
	)

happyReduce_24 = happySpecReduce_1  9 happyReduction_24
happyReduction_24 (HappyTerminal (ID happy_var_1))
	 =  HappyAbsSyn9
		 (Id happy_var_1
	)
happyReduction_24 _  = notHappyAtAll 

happyReduce_25 = happySpecReduce_3  9 happyReduction_25
happyReduction_25 (HappyAbsSyn9  happy_var_3)
	_
	(HappyAbsSyn9  happy_var_1)
	 =  HappyAbsSyn9
		 (LogBinOp happy_var_1 happy_var_3
	)
happyReduction_25 _ _ _  = notHappyAtAll 

happyReduce_26 = happySpecReduce_3  9 happyReduction_26
happyReduction_26 (HappyAbsSyn9  happy_var_3)
	_
	(HappyAbsSyn9  happy_var_1)
	 =  HappyAbsSyn9
		 (LogBinOp happy_var_1 happy_var_3
	)
happyReduction_26 _ _ _  = notHappyAtAll 

happyReduce_27 = happySpecReduce_3  9 happyReduction_27
happyReduction_27 (HappyAbsSyn9  happy_var_3)
	_
	(HappyAbsSyn9  happy_var_1)
	 =  HappyAbsSyn9
		 (RelOp happy_var_1 happy_var_3
	)
happyReduction_27 _ _ _  = notHappyAtAll 

happyReduce_28 = happySpecReduce_3  9 happyReduction_28
happyReduction_28 (HappyAbsSyn9  happy_var_3)
	_
	(HappyAbsSyn9  happy_var_1)
	 =  HappyAbsSyn9
		 (RelOp happy_var_1 happy_var_3
	)
happyReduction_28 _ _ _  = notHappyAtAll 

happyReduce_29 = happySpecReduce_3  9 happyReduction_29
happyReduction_29 (HappyAbsSyn9  happy_var_3)
	_
	(HappyAbsSyn9  happy_var_1)
	 =  HappyAbsSyn9
		 (RelOp happy_var_1 happy_var_3
	)
happyReduction_29 _ _ _  = notHappyAtAll 

happyReduce_30 = happySpecReduce_3  9 happyReduction_30
happyReduction_30 (HappyAbsSyn9  happy_var_3)
	_
	(HappyAbsSyn9  happy_var_1)
	 =  HappyAbsSyn9
		 (RelOp happy_var_1 happy_var_3
	)
happyReduction_30 _ _ _  = notHappyAtAll 

happyReduce_31 = happySpecReduce_3  9 happyReduction_31
happyReduction_31 (HappyAbsSyn9  happy_var_3)
	_
	(HappyAbsSyn9  happy_var_1)
	 =  HappyAbsSyn9
		 (RelOp happy_var_1 happy_var_3
	)
happyReduction_31 _ _ _  = notHappyAtAll 

happyReduce_32 = happySpecReduce_3  9 happyReduction_32
happyReduction_32 (HappyAbsSyn9  happy_var_3)
	_
	(HappyAbsSyn9  happy_var_1)
	 =  HappyAbsSyn9
		 (RelOp happy_var_1 happy_var_3
	)
happyReduction_32 _ _ _  = notHappyAtAll 

happyReduce_33 = happySpecReduce_2  9 happyReduction_33
happyReduction_33 (HappyAbsSyn9  happy_var_2)
	_
	 =  HappyAbsSyn9
		 (LogUnOp happy_var_2
	)
happyReduction_33 _ _  = notHappyAtAll 

happyReduce_34 = happySpecReduce_3  9 happyReduction_34
happyReduction_34 (HappyAbsSyn9  happy_var_3)
	_
	(HappyAbsSyn9  happy_var_1)
	 =  HappyAbsSyn9
		 (IntBinOp happy_var_1 happy_var_3
	)
happyReduction_34 _ _ _  = notHappyAtAll 

happyReduce_35 = happySpecReduce_3  9 happyReduction_35
happyReduction_35 (HappyAbsSyn9  happy_var_3)
	_
	(HappyAbsSyn9  happy_var_1)
	 =  HappyAbsSyn9
		 (IntBinOp happy_var_1 happy_var_3
	)
happyReduction_35 _ _ _  = notHappyAtAll 

happyReduce_36 = happySpecReduce_3  9 happyReduction_36
happyReduction_36 (HappyAbsSyn9  happy_var_3)
	_
	(HappyAbsSyn9  happy_var_1)
	 =  HappyAbsSyn9
		 (IntBinOp happy_var_1 happy_var_3
	)
happyReduction_36 _ _ _  = notHappyAtAll 

happyReduce_37 = happySpecReduce_3  9 happyReduction_37
happyReduction_37 (HappyAbsSyn9  happy_var_3)
	_
	(HappyAbsSyn9  happy_var_1)
	 =  HappyAbsSyn9
		 (IntBinOp happy_var_1 happy_var_3
	)
happyReduction_37 _ _ _  = notHappyAtAll 

happyReduce_38 = happySpecReduce_2  9 happyReduction_38
happyReduction_38 (HappyAbsSyn9  happy_var_2)
	_
	 =  HappyAbsSyn9
		 (Process.Left happy_var_2
	)
happyReduction_38 _ _  = notHappyAtAll 

happyReduce_39 = happySpecReduce_2  9 happyReduction_39
happyReduction_39 (HappyAbsSyn9  happy_var_2)
	_
	 =  HappyAbsSyn9
		 (Process.Right happy_var_2
	)
happyReduction_39 _ _  = notHappyAtAll 

happyReduce_40 = happySpecReduce_3  9 happyReduction_40
happyReduction_40 _
	(HappyAbsSyn9  happy_var_2)
	_
	 =  HappyAbsSyn9
		 (happy_var_2
	)
happyReduction_40 _ _ _  = notHappyAtAll 

happyReduce_41 = happySpecReduce_3  9 happyReduction_41
happyReduction_41 (HappyAbsSyn9  happy_var_3)
	_
	(HappyAbsSyn9  happy_var_1)
	 =  HappyAbsSyn9
		 (Pair happy_var_1 happy_var_3
	)
happyReduction_41 _ _ _  = notHappyAtAll 

happyNewToken action sts stk [] =
	action 51 51 notHappyAtAll (HappyState action) sts stk []

happyNewToken action sts stk (tk:tks) =
	let cont i = action i i tk (HappyState action) sts stk tks in
	case tk of {
	NEW -> cont 10;
	Lexer.INT happy_dollar_dollar -> cont 11;
	TRUE -> cont 12;
	FALSE -> cont 13;
	ID happy_dollar_dollar -> cont 14;
	LET -> cont 15;
	IN -> cont 16;
	INL -> cont 17;
	INR -> cont 18;
	CASE -> cont 19;
	OF -> cont 20;
	IF -> cont 21;
	THEN -> cont 22;
	ELSE -> cont 23;
	ARROW -> cont 24;
	Lexer.EQ -> cont 25;
	PAR -> cont 26;
	LPAR -> cont 27;
	RPAR -> cont 28;
	Lexer.LT -> cont 29;
	Lexer.GT -> cont 30;
	Lexer.LE -> cont 31;
	Lexer.GE -> cont 32;
	Lexer.NE -> cont 33;
	AND -> cont 34;
	OR -> cont 35;
	NOT -> cont 36;
	LBRACK -> cont 37;
	RBRACK -> cont 38;
	LBRACE -> cont 39;
	RBRACE -> cont 40;
	EMARK -> cont 41;
	QMARK -> cont 42;
	COMMA -> cont 43;
	DOT -> cont 44;
	COLON -> cont 45;
	STAR -> cont 46;
	PLUS -> cont 47;
	MINUS -> cont 48;
	SLASH -> cont 49;
	UNDERSCORE -> cont 50;
	_ -> happyError' (tk:tks)
	}

happyError_ 51 tk tks = happyError' tks
happyError_ _ tk tks = happyError' (tk:tks)

newtype HappyIdentity a = HappyIdentity a
happyIdentity = HappyIdentity
happyRunIdentity (HappyIdentity a) = a

instance Monad HappyIdentity where
    return = HappyIdentity
    (HappyIdentity p) >>= q = q p

happyThen :: () => HappyIdentity a -> (a -> HappyIdentity b) -> HappyIdentity b
happyThen = (>>=)
happyReturn :: () => a -> HappyIdentity a
happyReturn = (return)
happyThen1 m k tks = (>>=) m (\a -> k a tks)
happyReturn1 :: () => a -> b -> HappyIdentity a
happyReturn1 = \a tks -> (return) a
happyError' :: () => [(Token)] -> HappyIdentity a
happyError' = HappyIdentity . throwError

process tks = happyRunIdentity happySomeParser where
  happySomeParser = happyThen (happyParse action_0 tks) (\x -> case x of {HappyAbsSyn4 z -> happyReturn z; _other -> notHappyAtAll })

happySeq = happyDontSeq


data Pattern = PVar String
             | PPair Pattern Pattern

expandReceive :: String -> Pattern -> Process () -> Process ()
expandReceive u (PVar x) p = Receive u x () p
expandReceive u pattern p = Receive u "_msg" () $ expandLet pattern (Id "_msg") p

expandCase :: Pattern -> Process () -> (String, Process ())
expandCase (PVar x) p = (x, p)
expandCase pattern p = ("_var", expandLet pattern (Id "_var") p)

expandLet :: Pattern -> Expression -> Process () -> Process ()
expandLet = expand "_var"
  where
    expand _ (PVar x) e p = Let x () "_" () (Pair e UNIT) p
    expand _ (PPair (PVar x) (PVar y)) e p = Let x () y () e p
    expand path (PPair p1 p2) e p = let pathl = path ++ ".1" in
                                    let pathr = path ++ ".2" in
                                    Let pathl () pathr () e (expand pathl p1 (Id pathl)
							     (expand pathr p2 (Id pathr) p))

throwError :: [Token] -> a
throwError tokens = error ("Parse error on "++ (show $ head tokens) ++ "\n")
{-# LINE 1 "templates/GenericTemplate.hs" #-}
{-# LINE 1 "templates/GenericTemplate.hs" #-}
{-# LINE 1 "<built-in>" #-}
{-# LINE 1 "<command-line>" #-}
{-# LINE 1 "templates/GenericTemplate.hs" #-}
-- Id: GenericTemplate.hs,v 1.26 2005/01/14 14:47:22 simonmar Exp 

{-# LINE 30 "templates/GenericTemplate.hs" #-}








{-# LINE 51 "templates/GenericTemplate.hs" #-}

{-# LINE 61 "templates/GenericTemplate.hs" #-}

{-# LINE 70 "templates/GenericTemplate.hs" #-}

infixr 9 `HappyStk`
data HappyStk a = HappyStk a (HappyStk a)

-----------------------------------------------------------------------------
-- starting the parse

happyParse start_state = happyNewToken start_state notHappyAtAll notHappyAtAll

-----------------------------------------------------------------------------
-- Accepting the parse

-- If the current token is (1), it means we've just accepted a partial
-- parse (a %partial parser).  We must ignore the saved token on the top of
-- the stack in this case.
happyAccept (1) tk st sts (_ `HappyStk` ans `HappyStk` _) =
	happyReturn1 ans
happyAccept j tk st sts (HappyStk ans _) = 
	 (happyReturn1 ans)

-----------------------------------------------------------------------------
-- Arrays only: do the next action

{-# LINE 148 "templates/GenericTemplate.hs" #-}

-----------------------------------------------------------------------------
-- HappyState data type (not arrays)



newtype HappyState b c = HappyState
        (Int ->                    -- token number
         Int ->                    -- token number (yes, again)
         b ->                           -- token semantic value
         HappyState b c ->              -- current state
         [HappyState b c] ->            -- state stack
         c)



-----------------------------------------------------------------------------
-- Shifting a token

happyShift new_state (1) tk st sts stk@(x `HappyStk` _) =
     let (i) = (case x of { HappyErrorToken (i) -> i }) in
--     trace "shifting the error token" $
     new_state i i tk (HappyState (new_state)) ((st):(sts)) (stk)

happyShift new_state i tk st sts stk =
     happyNewToken new_state ((st):(sts)) ((HappyTerminal (tk))`HappyStk`stk)

-- happyReduce is specialised for the common cases.

happySpecReduce_0 i fn (1) tk st sts stk
     = happyFail (1) tk st sts stk
happySpecReduce_0 nt fn j tk st@((HappyState (action))) sts stk
     = action nt j tk st ((st):(sts)) (fn `HappyStk` stk)

happySpecReduce_1 i fn (1) tk st sts stk
     = happyFail (1) tk st sts stk
happySpecReduce_1 nt fn j tk _ sts@(((st@(HappyState (action))):(_))) (v1`HappyStk`stk')
     = let r = fn v1 in
       happySeq r (action nt j tk st sts (r `HappyStk` stk'))

happySpecReduce_2 i fn (1) tk st sts stk
     = happyFail (1) tk st sts stk
happySpecReduce_2 nt fn j tk _ ((_):(sts@(((st@(HappyState (action))):(_))))) (v1`HappyStk`v2`HappyStk`stk')
     = let r = fn v1 v2 in
       happySeq r (action nt j tk st sts (r `HappyStk` stk'))

happySpecReduce_3 i fn (1) tk st sts stk
     = happyFail (1) tk st sts stk
happySpecReduce_3 nt fn j tk _ ((_):(((_):(sts@(((st@(HappyState (action))):(_))))))) (v1`HappyStk`v2`HappyStk`v3`HappyStk`stk')
     = let r = fn v1 v2 v3 in
       happySeq r (action nt j tk st sts (r `HappyStk` stk'))

happyReduce k i fn (1) tk st sts stk
     = happyFail (1) tk st sts stk
happyReduce k nt fn j tk st sts stk
     = case happyDrop (k - ((1) :: Int)) sts of
	 sts1@(((st1@(HappyState (action))):(_))) ->
        	let r = fn stk in  -- it doesn't hurt to always seq here...
       		happyDoSeq r (action nt j tk st1 sts1 r)

happyMonadReduce k nt fn (1) tk st sts stk
     = happyFail (1) tk st sts stk
happyMonadReduce k nt fn j tk st sts stk =
        happyThen1 (fn stk tk) (\r -> action nt j tk st1 sts1 (r `HappyStk` drop_stk))
       where (sts1@(((st1@(HappyState (action))):(_)))) = happyDrop k ((st):(sts))
             drop_stk = happyDropStk k stk

happyMonad2Reduce k nt fn (1) tk st sts stk
     = happyFail (1) tk st sts stk
happyMonad2Reduce k nt fn j tk st sts stk =
       happyThen1 (fn stk tk) (\r -> happyNewToken new_state sts1 (r `HappyStk` drop_stk))
       where (sts1@(((st1@(HappyState (action))):(_)))) = happyDrop k ((st):(sts))
             drop_stk = happyDropStk k stk





             new_state = action


happyDrop (0) l = l
happyDrop n ((_):(t)) = happyDrop (n - ((1) :: Int)) t

happyDropStk (0) l = l
happyDropStk n (x `HappyStk` xs) = happyDropStk (n - ((1)::Int)) xs

-----------------------------------------------------------------------------
-- Moving to a new state after a reduction

{-# LINE 246 "templates/GenericTemplate.hs" #-}
happyGoto action j tk st = action j j tk (HappyState action)


-----------------------------------------------------------------------------
-- Error recovery ((1) is the error token)

-- parse error if we are in recovery and we fail again
happyFail (1) tk old_st _ stk@(x `HappyStk` _) =
     let (i) = (case x of { HappyErrorToken (i) -> i }) in
--	trace "failing" $ 
        happyError_ i tk

{-  We don't need state discarding for our restricted implementation of
    "error".  In fact, it can cause some bogus parses, so I've disabled it
    for now --SDM

-- discard a state
happyFail  (1) tk old_st (((HappyState (action))):(sts)) 
						(saved_tok `HappyStk` _ `HappyStk` stk) =
--	trace ("discarding state, depth " ++ show (length stk))  $
	action (1) (1) tk (HappyState (action)) sts ((saved_tok`HappyStk`stk))
-}

-- Enter error recovery: generate an error token,
--                       save the old token and carry on.
happyFail  i tk (HappyState (action)) sts stk =
--      trace "entering error recovery" $
	action (1) (1) tk (HappyState (action)) sts ( (HappyErrorToken (i)) `HappyStk` stk)

-- Internal happy errors:

notHappyAtAll :: a
notHappyAtAll = error "Internal Happy error\n"

-----------------------------------------------------------------------------
-- Hack to get the typechecker to accept our action functions







-----------------------------------------------------------------------------
-- Seq-ing.  If the --strict flag is given, then Happy emits 
--	happySeq = happyDoSeq
-- otherwise it emits
-- 	happySeq = happyDontSeq

happyDoSeq, happyDontSeq :: a -> b -> b
happyDoSeq   a b = a `seq` b
happyDontSeq a b = b

-----------------------------------------------------------------------------
-- Don't inline any functions from the template.  GHC has a nasty habit
-- of deciding to inline happyGoto everywhere, which increases the size of
-- the generated parser quite a bit.

{-# LINE 312 "templates/GenericTemplate.hs" #-}
{-# NOINLINE happyShift #-}
{-# NOINLINE happySpecReduce_0 #-}
{-# NOINLINE happySpecReduce_1 #-}
{-# NOINLINE happySpecReduce_2 #-}
{-# NOINLINE happySpecReduce_3 #-}
{-# NOINLINE happyReduce #-}
{-# NOINLINE happyMonadReduce #-}
{-# NOINLINE happyGoto #-}
{-# NOINLINE happyFail #-}

-- end of Happy Template.
