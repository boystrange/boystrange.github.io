-- This file is part of Hypha.
--
-- Hypha is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- (at your option) any later version.
--
-- Hypha is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
--
-- You should have received a copy of the GNU General Public License
-- along with Hypha.  If not, see <http://www.gnu.org/licenses/>.
--
-- Copyright 2013 Luca Padovani

module Solver where

import Type;
import Environment;
import qualified Data.Set as S;
import qualified Data.Map as M;
import qualified Relation as R;

generateAssignments :: [Int] -> [UseEnvironment]
generateAssignments uvars =
    map (\a -> M.fromList $ zip uvars a) (allAssignments $ length uvars)

allAssignments :: Int -> [[Use]]
allAssignments 0 = [[]]
allAssignments n =
    let a = allAssignments (n - 1) in
    let zero = map (Zero :) a in
    let one = map (One :) a in
    let omega = map (Omega :) a in
    zero ++ one ++ omega

evaluate :: UseEnvironment -> Use -> Use
evaluate a (UVar x) = case M.lookup x a of
                          Nothing -> error "fatal internal error"
                          Just u -> u
evaluate _ u = u

findUseSolutions :: R.Relation Use ->
                    R.Relation Use ->
                    R.Relation Use ->
                    [UseEnvironment]
findUseSolutions lt le co =
    let dom = R.domain $ R.union lt $ R.union le co in
    let uvars = concat $ map getUseVar dom in
    filter checkUseSolution (generateAssignments uvars)
    where
      getUseVar (UVar uvar) = [uvar]
      getUseVar _ = []

      checkUseSolution a =
          all (checkUseConstraint a ltU) (R.toList lt) &&
          all (checkUseConstraint a leU) (R.toList le) &&
          all (checkUseConstraint a coU) (R.toList co)

      checkUseConstraint a f (x, y) = f (evaluate a x) (evaluate a y)


findUseSolution :: R.Relation Use ->
                   R.Relation Use ->
                   R.Relation Use ->
                   Maybe UseEnvironment
findUseSolution lt le co =
    case findUseSolutions lt le co of
      [] -> Nothing
      (as : _) -> Just as

type TVarMap = M.Map (S.Set Type) Int

solve :: UseEnvironment -> R.Relation Type -> R.Relation Type -> [(Type, Type)]
solve ua le0 co =
    map (\t -> (t, def 0 M.empty M.empty (S.singleton t))) domain
    where
      domain = R.domain st

      le = R.reflexiveClosure le0

      st = R.reflexiveClosure $ R.transitiveClosure $ R.symmetricClosure $ R.union le co

      leClosure :: S.Set Type -> S.Set Type
      leClosure ts = S.filter proper $ R.inverseImage ts le

      stClosure :: S.Set Type -> S.Set Type
      stClosure ts = S.filter proper $ R.image ts st

      extractChannel :: [Type] -> ([Type], [Use], [Use])
      extractChannel [] = ([], [], [])
      extractChannel (TChannel t k1 k2 : ts) =
          let (ts', k1s, k2s) = extractChannel ts in
          (t : ts', k1 : k1s, k2 : k2s)
      extractChannel (t : _) = error $ "type error: expected channel, got " ++ show t

      extractPair :: [Type] -> ([Type], [Type])
      extractPair [] = ([], [])
      extractPair (TPair t1 t2 : ts) =
          let (s1s, s2s) = extractPair ts in
          (t1 : s1s, t2 : s2s)
      extractPair (t : _) = error $ "type error: expected pair, got " ++ show t

      extractSum :: [Type] -> ([Type], [Type])
      extractSum [] = ([], [])
      extractSum (TSum t1 t2 : ts) =
          let (s1s, s2s) = extractSum ts in
          (t1 : s1s, t2 : s2s)
      extractSum (t : _) = error $ "type error: expected sum, got " ++ show t

      possiblyRec :: Int -> Type -> Type
      possiblyRec tvar t | S.member tvar $ ftv t = TRec tvar t
                         | otherwise = t

      def :: Int -> TVarMap -> TVarMap -> S.Set Type -> Type
      def nextVar dMap zMap tset =
          case M.lookup tset dMap of
            Just tvar -> TVar tvar
            Nothing ->
                let dMap' = M.insert tset nextVar dMap in
                let nextVar' = nextVar + 1 in
                let t = case S.toList $ leClosure tset of
                          ts@(TChannel _ _ _ : _) ->
                              let (ts', k1s, k2s) = extractChannel ts in
                              let k1sup = foldl supU Zero (map (evaluate ua) k1s) in
                              let k2sup = foldl supU Zero (map (evaluate ua) k2s) in
                              TChannel (def nextVar' dMap' zMap (S.fromList ts')) k1sup k2sup
                          ts@(TPair _ _ : _) ->
                              let (t1s, t2s) = extractPair ts in
                              let t1 = def nextVar' dMap' zMap (S.fromList t1s) in
                              let t2 = def nextVar' dMap' zMap (S.fromList t2s) in
                              TPair t1 t2
                          ts@(TSum _ _ : _) ->
                              let (t1s, t2s) = extractSum ts in
                              let t1 = def nextVar' dMap' zMap (S.fromList t1s) in
                              let t2 = def nextVar' dMap' zMap (S.fromList t2s) in
                              TSum t1 t2
                          _ -> zero nextVar dMap zMap tset
                in
                  possiblyRec nextVar t

      zero :: Int -> TVarMap -> TVarMap -> S.Set Type -> Type
      zero nextVar dMap zMap tset =
          case M.lookup tset zMap of
            Just tvar -> TVar tvar
            Nothing ->
                let zMap' = M.insert tset nextVar zMap in
                let nextVar' = nextVar + 1 in
                let t = case S.toList $ stClosure tset of
                          [] -> TUnit
                          [t] | basic t -> t
                          ts@(TChannel _ _ _ : _) ->
                              let (ts', _, _) = extractChannel ts in
                              TChannel (def nextVar' dMap zMap' (S.fromList ts')) Zero Zero
                          ts@(TPair _ _ : _) ->
                              let (t1s, t2s) = extractPair ts in
                              let t1 = zero nextVar' dMap zMap' (S.fromList t1s) in
                              let t2 = zero nextVar' dMap zMap' (S.fromList t2s) in
                              TPair t1 t2
                          ts@(TSum _ _ : _) ->
                              let (t1s, t2s) = extractSum ts in
                              let t1 = zero nextVar' dMap zMap' (S.fromList t1s) in
                              let t2 = zero nextVar' dMap zMap' (S.fromList t2s) in
                              TSum t1 t2
                          _ -> error "type error"
                in
                  possiblyRec nextVar t
