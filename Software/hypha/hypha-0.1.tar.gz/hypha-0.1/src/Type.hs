-- This file is part of Hypha.
--
-- Hypha is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- (at your option) any later version.
--
-- Hypha is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
--
-- You should have received a copy of the GNU General Public License
-- along with Hypha.  If not, see <http://www.gnu.org/licenses/>.
--
-- Copyright 2013 Luca Padovani

module Type where

import Data.Char (chr, ord);
import qualified Data.Set as S;

data Use = Zero
         | One
         | Omega
         | UVar Int
           deriving (Eq, Ord)

data Type = TVar Int
          | TUnit
          | TInt
          | TChannel Type Use Use
          | TPair Type Type
          | TSum Type Type
          | TRec Int Type
            deriving (Eq, Ord)

boolType :: Type
boolType = TSum TUnit TUnit

instance Show Use where
    show Zero = "0"
    show One = "1"
    show Omega = "ω"
    show (UVar n) = "ρ" ++ show n

instance Show Type where
--    show = showMap (\n -> "t" ++ show n)
    show = showPretty

showPretty :: Type -> String
showPretty = aux 0 []
    where
      aux _ _ TUnit = "Unit"
      aux _ _ TInt = "Int"
      aux _ _ (TSum TUnit TUnit) = "Bool"
      aux _ vmap (TVar n) =
          case lookup n vmap of
            Nothing -> "t" ++ show n
            Just m -> nameOfVar m
      aux next vmap (TChannel t u1 u2) = "[" ++ aux next vmap t ++ "]{" ++ show u1 ++ "," ++ show u2 ++ "}"
      aux next vmap (TPair t s) = "(" ++ aux next vmap t ++ " × " ++ aux next vmap s ++ ")"
      aux next vmap (TSum t s) = "(" ++ aux next vmap t ++ " ⊕ " ++ aux next vmap s ++ ")"
      aux next vmap (TRec n t) =
          let next' = next + 1 in
          let vmap' = (n, next) : vmap in
          let ts = aux next' vmap' t in
          let tsp = case t of
                      TPair _ _ -> "(" ++ ts ++ ")"
                      TSum _ _ -> "(" ++ ts ++ ")"
                      _ -> ts
          in
            "μ" ++ nameOfVar next ++ "." ++ tsp

      nameOfVar :: Int -> String
      nameOfVar n = [chr $ ord 'A' + n `mod` 26] ++ if n < 26 then "" else show (n `div` 26)

ltU :: Use -> Use -> Bool
ltU Zero One = True
ltU Zero Omega = True
ltU _ _ = False

leU :: Use -> Use -> Bool
leU Zero _ = True
leU u v | u == v = True
leU _ _ = False

coU :: Use -> Use -> Bool
coU Zero _ = True
coU _ Zero = True
coU Omega Omega = True
coU _ _ = False

supU :: Use -> Use -> Use
supU u v | leU u v = v
         | leU v u = u

basic :: Type -> Bool
basic TUnit = True
basic TInt = True
basic _ = False

proper :: Type -> Bool
proper (TVar _) = False
proper _ = True

fuv :: Use -> S.Set Int
fuv (UVar uvar) = S.singleton uvar
fuv _ = S.empty

ftv :: Type -> S.Set Int
ftv (TVar tvar) = S.singleton tvar
ftv (TChannel t _ _) = ftv t
ftv (TPair t s) = ftv t `S.union` ftv s
ftv (TSum t s) = ftv t `S.union` ftv s
ftv (TRec tvar t) = S.delete tvar $ ftv t
ftv _ = S.empty

