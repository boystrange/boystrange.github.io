-- This file is part of Hypha.
--
-- Hypha is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- (at your option) any later version.
--
-- Hypha is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
--
-- You should have received a copy of the GNU General Public License
-- along with Hypha.  If not, see <http://www.gnu.org/licenses/>.
--
-- Copyright 2013 Luca Padovani

module Partitioner where

import Type
import qualified Relation as R;
import qualified Data.Set as S;

data UseVarRelation = UVR Int Int

findVarRelations :: R.Relation Use -> R.Relation Int
findVarRelations = R.fromList . aux . R.toList
    where
      aux [] = []
      aux ((UVar r1, UVar r2) : rs) = (r1, r2) : aux rs
      aux ((UVar r, _) : rs) = (r, r) : aux rs
      aux ((_, UVar r) : rs) = (r, r) : aux rs
      aux (_ : rs) = aux rs

partitionUseConstraints :: R.Relation Use -> R.Relation Use -> R.Relation Use ->
                           [(R.Relation Use, R.Relation Use, R.Relation Use)]
partitionUseConstraints lt le co =
    let vrs = findVarRelations lt `R.union` findVarRelations le `R.union` findVarRelations co in
    let vrs' = (R.transitiveClosure . R.symmetricClosure . R.reflexiveClosure) vrs in
    map (\uvars -> (R.filter (check uvars) lt, R.filter (check uvars) le, R.filter (check uvars) co)) (R.partition vrs')
    where
      check us k1 k2 = (S.union (fuv k1) (fuv k2)) `S.isSubsetOf` us