-- This file is part of Hypha.
--
-- Hypha is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- (at your option) any later version.
--
-- Hypha is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
--
-- You should have received a copy of the GNU General Public License
-- along with Hypha.  If not, see <http://www.gnu.org/licenses/>.
--
-- Copyright 2013 Luca Padovani

module Relation where

import qualified Data.List as L;
import qualified Data.Set as S;

type Relation a = S.Set (a, a)

domain :: Eq a => Relation a -> [a]
domain s = let l = S.toList s in
           L.nub $ L.map fst l ++ L.map snd l

empty :: Relation a
empty = S.empty

insert :: Ord a => a -> a -> Relation a -> Relation a
insert x y = S.insert (x, y)

toList :: Relation a -> [(a, a)]
toList r = S.toList r

fromList :: Ord a => [(a, a)] -> Relation a
fromList = S.fromList

inverse :: Ord a => Relation a -> Relation a
inverse = S.map (\(x, y) -> (y, x))

intersection :: Ord a => Relation a -> Relation a -> Relation a
intersection = S.intersection

difference :: Ord a => Relation a -> Relation a -> Relation a
difference = S.difference

union :: Ord a => Relation a -> Relation a -> Relation a
union = S.union

filter :: Ord a => (a -> a -> Bool) -> Relation a -> Relation a
filter f = S.filter (uncurry f)

select :: Ord a => S.Set a -> Relation a -> Relation a
select xs = Relation.filter (\x y -> x `S.member` xs || y `S.member` xs)

remove :: Ord a => S.Set a -> Relation a -> Relation a
remove xs = Relation.filter (\x y -> not (x `S.member` xs) && not (y `S.member` xs))

compose :: Ord a => Relation a -> Relation a -> Relation a
compose r s = S.fromList [ (x, z) | (x, y) <- S.toList r,
                                    (x', z) <- S.toList s,
                                    y == x' ]

generate :: (Ord a, Ord b) => (a -> a -> Relation b) -> Relation a -> Relation b
generate f = S.fold (\(x, y) s -> S.union (f x y) s) S.empty 

reflexiveClosure :: Ord a => Relation a -> Relation a
reflexiveClosure r = let dom = domain r in
                     Relation.union r $ Relation.fromList (zip dom dom)

symmetricClosure :: Ord a => Relation a -> Relation a
symmetricClosure f = Relation.union f $ inverse f

transitiveClosure :: Ord a => Relation a -> Relation a
transitiveClosure = limit (\r -> r `Relation.union` (compose r r))
    where
      limit :: Eq a => (a -> a) -> a -> a
      limit f x =
          let y = f x in
          if x == y then x else limit f y

inverseImage :: Ord a => S.Set a -> Relation a -> S.Set a
inverseImage s = S.fold (\(x, y) res -> if S.member y s then S.insert x res else res) S.empty

image :: Ord a => S.Set a -> Relation a -> S.Set a
image s = S.fold (\(x, y) res -> if S.member x s then S.insert y res else res) S.empty

partition :: Ord a => Relation a -> [S.Set a]
partition r | S.null r = []
partition r = let (e, _) = S.findMin r in
              let ec = image (S.singleton e) r in
              ec : partition (remove ec r)
