-- This file is part of Hypha.
--
-- Hypha is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- (at your option) any later version.
--
-- Hypha is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
--
-- You should have received a copy of the GNU General Public License
-- along with Hypha.  If not, see <http://www.gnu.org/licenses/>.
--
-- Copyright 2013 Luca Padovani

module Generator where

import Type;
import Process;
import qualified Environment as E;
import qualified Relation as R;
import qualified Control.Monad.State.Lazy as ST;

data GeneratorState = GeneratorState {
      leConstraints :: R.Relation Type,
      cConstraints :: R.Relation Type,
      pConstraints :: R.Relation Use,
      varId :: Int
    }

emptyState :: GeneratorState
emptyState = GeneratorState {
               pConstraints = R.empty,
               leConstraints = R.empty,
               cConstraints = R.empty,
               varId = 0
             }

type Generator a = ST.State GeneratorState a
type Constraints = (R.Relation Type, -- ≤ 
                    R.Relation Type, -- ~
                    R.Relation Use,  -- <
                    R.Relation Use,  -- ≤
                    R.Relation Use)  -- ~

addPConstraint :: Use -> Generator ()
addPConstraint u = 
    ST.modify (\st -> st { pConstraints = R.insert Zero u (pConstraints st) } )

addLEConstraint :: Type -> Type -> Generator ()
addLEConstraint t s =
    ST.modify (\st -> st { leConstraints = R.insert t s (leConstraints st) } )

addEQConstraint :: Type -> Type -> Generator ()
addEQConstraint t s = do addLEConstraint t s 
                         addLEConstraint s t

addCConstraint :: Type -> Type -> Generator ()
addCConstraint t s =
    ST.modify (\st -> st { cConstraints = R.insert t s (cConstraints st) } )

getNewVar :: Generator Int
getNewVar =
    do old <- ST.get
       ST.modify (\st -> st {varId = (varId st) + 1})
       return (varId old)

combine :: E.TypeEnvironment -> E.TypeEnvironment -> Generator E.TypeEnvironment
combine env1 env2 =
    do env <- aux (E.toSortedList env1) (E.toSortedList env2)
       return $ E.fromSortedList env
    where
      aux :: [(Name, Type)] -> [(Name, Type)] -> Generator [(Name, Type)]
      aux [] env = return env
      aux env [] = return env
      aux ((x, tx) : xts) ((y, ty) : yts) | x == y =
                                              do tvar <- getNewVar
                                                 addCConstraint tx ty
                                                 addLEConstraint tx (TVar tvar)
                                                 addLEConstraint ty (TVar tvar)
                                                 env' <- aux xts yts
                                                 return $ (x, TVar tvar) : env'
      aux ((x, tx) : xts) yts@((y, _) : _) | x < y =
                                               do env' <- aux xts yts
                                                  return $ (x, tx) : env'
      aux xts@((x, _) : _) ((y, ty) : yts) | y < x =
                                               do env' <- aux xts yts
                                                  return $ (y, ty) : env'
      aux _ _ = error "impossible"

merge :: E.TypeEnvironment -> E.TypeEnvironment -> Generator E.TypeEnvironment
merge env1 env2 =
    do env <- aux (E.toSortedList env1) (E.toSortedList env2)
       return $ E.fromSortedList env
    where
      aux :: [(Name, Type)] -> [(Name, Type)] -> Generator [(Name, Type)]
      aux [] [] = return []
      aux ((x, tx) : xts) [] =
          do addCConstraint tx tx
             env' <- aux xts []
             return $ (x, tx) : env'
      aux [] ((y, ty) : yts) =
          do addCConstraint ty ty
             env' <- aux [] yts
             return $ (y, ty) : env'
      aux ((x, tx) : xts) ((y, ty) : yts) | x == y =
                                              do addLEConstraint tx ty
                                                 addLEConstraint ty tx
                                                 env' <- aux xts yts
                                                 return $ (x, tx) : env'
      aux ((x, tx) : xts) yts@((y, _) : _) | x < y =
                                               do addCConstraint tx tx
                                                  env' <- aux xts yts
                                                  return $ (x, tx) : env'
      aux xts@((x, _) : _) ((y, ty) : yts) | y < x =
                                               do addCConstraint ty ty
                                                  env' <- aux xts yts
                                                  return $ (y, ty) : env'

getType :: Name -> E.TypeEnvironment -> Generator (Type, E.TypeEnvironment)
getType x env = case E.lookup x env of
                  Just xt -> return (xt, env)
                  Nothing -> do tvar <- getNewVar
                                let xt = TVar tvar
                                addCConstraint xt xt
                                return (xt, E.insert x xt env)

allConstraints :: Bool -> R.Relation Type -> R.Relation Type -> R.Relation Use -> Constraints
allConstraints closeSt leT coT ltU =
    limit leT coT R.empty R.empty
    where
      closure = if closeSt then R.transitiveClosure . R.symmetricClosure else id

      limit leT coT leU coU =
          let (leT', coT', leU', coU') = step leT coT leU coU in
          if leT == leT' && coT == coT' && leU == leU' && coU == coU' then
              (leT, coT, ltU, leU, coU)
          else
              limit leT' coT' leU' coU'

      step leT coT leU coU =
          let leT1 = R.transitiveClosure leT in
          let eqT = R.intersection leT1 (R.inverse leT1) in
          let coT0 = R.symmetricClosure coT in
          let coT1 = coT0 `R.union` (R.compose eqT coT) in
          let coT2 = coT1 `R.union` (R.compose coT1 eqT) in
          let coT3 = coT2 `R.union` (R.compose leT coT2) in
          let stT = closure (leT1 `R.union` coT3) in
          let leT2 = leT1 `R.union` (R.generate eqStruct stT) in
          let leT3 = leT2 `R.union` (R.generate congT leT2) in
          let coT4 = coT3 `R.union` (R.generate congT coT3) in
          let leU' = leU `R.union` (R.generate congU leT3) in
          let coU' = coU `R.union` (R.generate congU coT4) in
          (leT3, coT4, leU', coU')

      eqStruct :: Type -> Type -> R.Relation Type
      eqStruct (TChannel t _ _) (TChannel s _ _) = R.fromList [(t, s), (s, t)]
      eqStruct _ _ = R.empty

      congT :: Type -> Type -> R.Relation Type
      congT (TPair t1 t2) (TPair s1 s2) = R.fromList [(t1, s1), (t2, s2)]
      congT (TSum t1 t2) (TSum s1 s2) = R.fromList [(t1, s1), (t2, s2)]
      congT _ _ = R.empty

      congU :: Type -> Type -> R.Relation Use
      congU (TChannel _ k1 k2) (TChannel _ k1' k2') = R.fromList [(k1, k1'), (k2, k2')]
      congU _ _ = R.empty

generate :: Bool -> Process () -> (Process Type, E.TypeEnvironment, Constraints)
generate closeSt p =
    let ((q, env), st) = ST.runState (auxP p) emptyState in
    (q, env, allConstraints closeSt (leConstraints st) (cConstraints st) (pConstraints st))
    where
      auxP :: Process () -> Generator (Process Type, E.TypeEnvironment)
      auxP Idle = return $ (Idle, E.empty)
      auxP (Receive u x () p) =
          do (p', env) <- auxP p
             (xt, env') <- getType x env
             uvar <- getNewVar
             let ut = TChannel xt (UVar uvar) Zero
             env'' <- combine (E.remove x env') (E.singleton u ut)
             addPConstraint (UVar uvar)
             return (Receive u x xt p', env'')
      auxP (Send u e) =
          do (t, env) <- auxE e
             uvar <- getNewVar
             let ut = TChannel t Zero (UVar uvar)
             env' <- combine env (E.singleton u ut)
             addPConstraint (UVar uvar)
             return (Send u e, env')
      auxP (Group p) =
          do (q, env) <- auxP p
             return (Group q, env)
      auxP (Par p q) =
          do (p', env1) <- auxP p
             (q', env2) <- auxP q
             env <- combine env1 env2
             return (Par p' q', env)
      auxP (Star p) =
          do (q, env) <- auxP p
             env' <- combine env env
             return (Star q, env')
      auxP (New a () p) =
          do (q, env) <- auxP p
             (at, env) <- getType a env
             let env' = E.remove a env
             tvar <- getNewVar
             uvar <- getNewVar
             let at' = TChannel (TVar tvar) (UVar uvar) (UVar uvar)
             addLEConstraint at at'
             addLEConstraint at' at
             return (New a at q, env')
      auxP (Let x () y () e p) =
          do (t, env) <- auxE e
             (q, env') <- auxP p
             (xt, env') <- getType x env'
             (yt, env') <- getType y env'
             env <- combine env (E.remove x (E.remove y env'))
             let et = TPair xt yt
             addLEConstraint t et
             addLEConstraint et t
             return (Let x xt y yt e q, env)
      auxP (Case e x () p y () q) =
          do (t, env) <- auxE e
             (p', env1) <- auxP p
             (xt, env1) <- getType x env1
             (q', env2) <- auxP q
             (yt, env2) <- getType y env2
             env' <- merge (E.remove x env1) (E.remove y env2)
             env' <- combine env env'
             let et = TSum xt yt
             addLEConstraint t et
             addLEConstraint et t
             return (Case e x xt p' y yt q', env')

      auxE :: Expression -> Generator (Type, E.TypeEnvironment)
      auxE (Id x) =
          do tvar <- getNewVar
             return (TVar tvar, E.singleton x (TVar tvar))

      auxE UNIT = return (TUnit, E.empty)

      auxE (INT _) = return (TInt, E.empty)

      auxE (LogBinOp e1 e2) =
          do (t1, env1) <- auxE e1
             (t2, env2) <- auxE e2
             env <- combine env1 env2
             addEQConstraint t1 boolType
             addEQConstraint t2 boolType
             return (boolType, env)
             
      auxE (LogUnOp e) =
          do (t, env) <- auxE e
             addEQConstraint t boolType
             return (boolType, env)
             
      auxE (RelOp e1 e2) =
          do (t1, env1) <- auxE e1
             (t2, env2) <- auxE e2
             env <- combine env1 env2
             addEQConstraint t1 t2
             return (boolType, env)
             
      auxE (IntBinOp e1 e2) =
          do (t1, env1) <- auxE e1
             (t2, env2) <- auxE e2
             env <- combine env1 env2
             addEQConstraint t1 TInt
             addEQConstraint t2 TInt
             return (TInt, env)
             
      auxE (Pair e1 e2) =
          do (t1, env1) <- auxE e1
             (t2, env2) <- auxE e2
             env <- combine env1 env2
             return (TPair t1 t2, env)

      auxE (Process.Left e) =
          do (t, env) <- auxE e
             tvar <- getNewVar
             return (TSum t (TVar tvar), env)

      auxE (Process.Right e) =
          do (t, env) <- auxE e
             tvar <- getNewVar
             return (TSum (TVar tvar) t, env)
