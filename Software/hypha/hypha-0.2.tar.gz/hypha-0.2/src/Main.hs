-- This file is part of Hypha.
--
-- Hypha is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- (at your option) any later version.
--
-- Hypha is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
--
-- You should have received a copy of the GNU General Public License
-- along with Hypha.  If not, see <http://www.gnu.org/licenses/>.
--
-- Copyright 2013 Luca Padovani

module Main (main) where

import qualified Parser;
import qualified Lexer;
import Process;
import Type;
import qualified Generator;
import qualified Solver;
import Environment as E;
import qualified Relation as R;
import Control.Monad;
import qualified Partitioner;
import System.Console.GetOpt;
import System.IO;
import System.Exit;
import System.Environment;
import qualified Data.List as L;

versionInfo :: String
versionInfo =
    "Hypha 0.2 - Type Reconstruction for the Linear π-Calculus\n"
    ++ "Copyright (C) 2013 Luca Padovani\n"
    ++ "License GPLv3+: GNU GPL version 3 or later <http://gnu.org/licenses/gpl.html>.\n"
    ++ "This is free software: you are free to change and redistribute it.\n"
    ++ "There is NO WARRANTY, to the extent permitted by law."

data Relation = LessEq | Less | Eq | Compat

instance Show Relation where
    show LessEq = "≤"
    show Compat = "≍"
    show Less = "<"
    show Eq = "="

applyU :: UseEnvironment -> Use -> Use
applyU ua k@(UVar uvar) =
    case E.lookup uvar ua of
      Nothing -> error $ "internal error: unsolved use variable " ++ show k
      Just k -> k
applyU _ k = k

applyT :: UseEnvironment -> [(Type, Type)] -> Type -> Type
applyT ua ta (TChannel t k1 k2) = TChannel (applyT ua ta t) (applyU ua k1) (applyU ua k2)
applyT ua ta (TPair t1 t2) = TPair (applyT ua ta t1) (applyT ua ta t2)
applyT ua ta (TSum t1 t2) = TSum (applyT ua ta t1) (applyT ua ta t2)
applyT ua ta (TRec tvar t) = TRec tvar (applyT ua ta t)
applyT ua ta t =
    case Prelude.lookup t ta of
      Nothing -> t
      Just s -> s

showConstraint :: Show a => Relation -> (a, a) -> String
showConstraint rel (x, y) = "  " ++ show x ++ " " ++ show rel ++ " " ++ show y

splitRelation :: Ord a => R.Relation a -> (R.Relation a, R.Relation a)
splitRelation r = let s = R.intersection r (R.inverse r) in
                  (s, R.difference r s)

main :: IO ()
main = do
  (args, file) <- getArgs >>= parse
  source <- readFile file
  let p = Parser.process $ Lexer.alexScanTokens source
  let closeSt = Closure `elem` args
  let (q, env, (leT, coT, ltU, leU, coU)) = Generator.generate closeSt p
  when (Verbose `elem` args)
       (do putStrLn "Process"
           putStrLn $ show q
           putStrLn "\nUnsolved type environment"
           forM_ (E.toSortedList env) (\(u, t) -> putStrLn $ "  " ++ u ++ " : " ++ show t)
           putStrLn "\nType constraints"
           let (eqT, leT') = splitRelation leT
           forM_ (R.toList $ R.filter (<) eqT) (putStrLn . showConstraint Eq)
           forM_ (R.toList $ R.filter (/=) leT') (putStrLn . showConstraint LessEq)
           putStrLn ""
           let (coT', _) = splitRelation coT
           forM_ (R.toList $ R.filter (<=) coT') (putStrLn . showConstraint Compat)
           putStrLn "\nUse constraints"
           forM_ (R.toList ltU) (putStrLn . showConstraint Less)
           putStrLn ""
           let (eqU, leU') = splitRelation leU
           forM_ (R.toList $ R.filter (<) eqU) (putStrLn . showConstraint Eq)
           forM_ (R.toList $ R.filter (/=) leU') (putStrLn . showConstraint LessEq)
           putStrLn ""
           let (coU', _) = splitRelation coU
           forM_ (R.toList $ R.filter (<=) coU') (putStrLn . showConstraint Compat))
  let ucS = if NoPartition `elem` args then
                [(ltU, leU, coU)]
            else
                Partitioner.partitionUseConstraints ltU leU coU
  when (Verbose `elem` args)
       (putStrLn $ "found " ++ show (length ucS) ++ " partition(s) of use constraints")
  let ucSolutions = map (\(ltU, leU, coU) -> Solver.findUseSolutions ltU leU coU) ucS
  case minimum ucSolutions of
    [] -> putStrLn "\nThere is no use solution"
    _ -> do let ua = E.combine $ map head ucSolutions
            let ta = Solver.solve ua leT coT
            when (Verbose `elem` args)
                 (do putStrLn "\nUse solution"
                     printUseAssignment ua
                     putStrLn "\nType solution"
                     forM_ ta (\(t, s) -> putStrLn $ "  " ++ show t ++ " = " ++ show s)
                     putStrLn "\nSolved type environment")
            forM_ (E.toSortedList env) (\(u, t) -> putStrLn $ "  " ++ u ++ " : " ++ show (applyT ua ta t))
    where
      printUseAssignment ua = forM_ (E.toSortedList ua) (\(uvar, u) -> putStrLn $ "  " ++ show (UVar uvar) ++ " = " ++ show u)

data Flag = NoPartition           -- --no-partition
          | Closure               -- -c --closure
          | Verbose               -- -v --verbose
          | Version               -- -V --version
          | Help                  -- --help
            deriving (Eq,Ord,Enum,Show,Bounded)
 
flags =
   [Option [] ["no-partition"] (NoArg NoPartition)
        "Do not partition use constraints",
    Option ['v'] ["verbose"]   (NoArg Verbose)
        "Print use and type constraints",
    Option ['c'] ["closure"]   (NoArg Closure)
        "Compute reflexive and transitive closure of compatibility constraints",
    Option ['V'] ["version"]   (NoArg Version)
        "Print version information",
    Option ['h'] ["help"]      (NoArg Help)
        "Print this help message"
   ]
 
parse argv =
    case getOpt Permute flags argv of
      (args, files, []) -> do
        when (Version `elem` args)
             (do hPutStrLn stderr versionInfo
                 exitWith ExitSuccess)
        when (null files || L.length files > 1 || Help `elem` args)
                 (do hPutStrLn stderr (usageInfo header flags)
                     exitWith ExitSuccess)
        return (args, head files)
 
      (_, _, errs) -> do
        hPutStrLn stderr (concat errs ++ usageInfo header flags)
        exitWith (ExitFailure 1)
 
    where
      header = "Usage: hypha [options] FILE"
