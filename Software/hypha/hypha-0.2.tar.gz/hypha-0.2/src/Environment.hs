-- This file is part of Hypha.
--
-- Hypha is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- (at your option) any later version.
--
-- Hypha is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
--
-- You should have received a copy of the GNU General Public License
-- along with Hypha.  If not, see <http://www.gnu.org/licenses/>.
--
-- Copyright 2013 Luca Padovani

module Environment where

import Type
import Process
import Data.Map as M
import Data.List as L

type Environment a b = M.Map a b
type UseEnvironment = Environment Int Use
type TypeEnvironment = Environment Name Type

empty :: Environment a b
empty = M.empty

insert :: Ord a => a -> b -> Environment a b -> Environment a b
insert = M.insert

lookup :: Ord a => a -> Environment a b -> Maybe b
lookup = M.lookup

singleton :: Ord a => a -> b -> Environment a b
singleton = M.singleton

remove :: Ord a => a -> Environment a b -> Environment a b
remove = M.delete

combine :: Ord a => [Environment a b] -> Environment a b
combine = M.unions

toSortedList :: Ord a => Environment a b -> [(a, b)]
toSortedList = M.toAscList

fromSortedList :: Ord a => [(a, b)] -> Environment a b
fromSortedList = M.fromAscList
