# Revision history for CobaltBlue

## 1.0  -- 2017-01-22

* First version. Released on an unsuspecting world.
