# Revision history for CobaltBlue

## 1.0  -- 2017-01-22

	* First version. Released on an unsuspecting world.

## 2.0  -- 2017-08-19

	* First implementation of deadlock analysis.
	* Changed handling of basic types (still experimental)

## 2.1  -- 2017-12-02

	* Fixed shameful bug in deadlock analysis algorithm.
