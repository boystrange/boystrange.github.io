module Dependencies where

import qualified Data.Set as S
import qualified Data.Partition as P

type DependencyRelation a = P.Partition a

empty :: P.Partition a
empty = P.empty

fromList :: Ord a => [a] -> P.Partition a
fromList xs = fromSet (S.fromList xs)

fromSet :: Ord a => S.Set a -> DependencyRelation a
fromSet xset = P.fromSets [xset]

union :: Ord a => P.Partition a -> P.Partition a -> P.Partition a
union d₁ d₂ = P.fromSets $ P.nontrivialSets d₁ ++ P.nontrivialSets d₂

delete :: Ord a => a -> DependencyRelation a -> DependencyRelation a
delete x = P.fromDisjointSets . map (S.delete x) . P.nontrivialSets

compatible :: Ord a => P.Partition a -> P.Partition a -> Either [a] ()
compatible d₁ d₂ =
  case circ of
    [] -> Right ()
    (cls : _) -> Left (S.toList cls)
  where
    circ = [ cls
           | cls₁ <- P.nontrivialSets d₁,
             cls₂ <- P.nontrivialSets d₂,
             let cls = S.intersection cls₁ cls₂,
             S.size cls > 1
           ]

