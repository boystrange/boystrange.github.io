(* This file is part of FuSe.                                           *)
(*                                                                      *)
(* FuSe is free software: you can redistribute it and/or modify         *)
(* it under the terms of the GNU General Public License as published by *)
(* the Free Software Foundation, either version 3 of the License, or    *)
(* (at your option) any later version.                                  *)
(*                                                                      *)
(* FuSe is distributed in the hope that it will be useful,              *)
(* but WITHOUT ANY WARRANTY; without even the implied warranty of       *)
(* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        *)
(* GNU General Public License for more details.                         *)
(*                                                                      *)
(* You should have received a copy of the GNU General Public License    *)
(* along with FuSe.  If not, see <http://www.gnu.org/licenses/>.        *)
(*                                                                      *)
(* Copyright 2015-2016 Luca Padovani                                    *)
       
type _0
type (+'a, -'b) st = { name : string;
		       channel : unit Event.channel;
		       mutable valid : bool }
type et            = (_0, _0) st
type +'a it        = ('a, _0) st
type -'a ot        = (_0, 'a) st
type (+'a, +'b) seq
type (+'a, +'b) choice = [ `True of 'a | `False of 'b ]
type +'a istar = (('a, 'b) seq it, et) choice it as 'b
type -'a ostar = (('a, 'a istar) seq it, et) choice ot

module SequenceMonoid = struct
  let select_left_end_elim = Obj.magic
  let accept_left_end_elim = Obj.magic

  let select_left_end_intro = Obj.magic
  let accept_left_end_intro = Obj.magic
				
  let select_right_end_elim = Obj.magic
  let accept_right_end_elim = Obj.magic

  let select_right_end_intro = Obj.magic
  let accept_right_end_intro = Obj.magic

  let receive_accept_left_assoc = Obj.magic
  let receive_select_left_assoc = Obj.magic
  let send_accept_left_assoc = Obj.magic
  let send_select_left_assoc = Obj.magic
				 
  let receive_accept_right_assoc = Obj.magic
  let receive_select_right_assoc = Obj.magic
  let send_accept_right_assoc = Obj.magic
  let send_select_right_assoc = Obj.magic
				  
  let accept_accept_left_assoc = Obj.magic
  let select_accept_left_assoc = Obj.magic
  let accept_select_left_assoc = Obj.magic
  let select_select_left_assoc = Obj.magic

  let accept_accept_right_assoc = Obj.magic
  let select_accept_right_assoc = Obj.magic
  let accept_select_right_assoc = Obj.magic
  let select_select_right_assoc = Obj.magic
end

module Bare = struct
  exception InvalidEndpoint
  exception UnusedValidEndpoint
	      
  let check_valid ep = if ep.valid then ep.valid <- false else raise InvalidEndpoint
  let same_channel u v = Obj.magic u == v
  let check_same_channel u v =
    if same_channel u v then () else raise InvalidEndpoint
  let check_invalid ep = if ep.valid then raise UnusedValidEndpoint
                   
  let fresh ep =
    let ep = { name = ep.name; channel = ep.channel; valid = true } in
    Gc.finalise check_invalid ep;
    ep

  (**********************************)
  (*** INITIATION AND TERMINATION ***)
  (**********************************)

  let create ?(name = "channel") () =
    let ch = Event.new_channel () in
    let ep1 = { name = name ^ "⁺"; channel = ch; valid = true } in
    let ep2 = { name = name ^ "⁻"; channel = ch; valid = true } in
    (ep1, ep2)

  let close = check_valid

  (****************)
  (*** IDENTITY ***)
  (****************)

  let same_session ep ep' = same_channel ep.channel ep'.channel

  let string_of_endpoint ep = ep.name
				
  (*****************)
  (*** LINEARITY ***)
  (*****************)
				
  let is_valid ep = ep.valid
                      
  let acquire ep =
    check_valid ep;
    fresh ep

  let try_acquire ep =
    if ep.valid then
      begin
	ep.valid <- false;
	Some (fresh ep)
      end
    else
      None

  (*********************************)
  (*** LOW-LEVEL MESSAGE PASSING ***)
  (*********************************)

  let select f ep =
    check_valid ep;
    Event.sync (Event.send ep.channel (Obj.magic f));
    Obj.magic (fresh ep)

  let accept ep =
    check_valid ep;
    Obj.magic (Event.sync (Event.receive ep.channel)) (fresh ep)
	      
  (***********************************)
  (*** MESSAGE PASSING AND CHOICES ***)
  (***********************************)
	      
  let send x = select (fun ep -> (x, ep))
  let receive = accept
  let select_true ep = select (fun x -> `True x) ep
  let select_false ep = select (fun x -> `False x) ep
  let branch = accept

  (******************************)      
  (*** SEQUENTIAL COMPOSITION ***)
  (******************************)      

  let select_seq_bind f ep =
    check_valid ep;
    let result, ep' = f (Obj.magic (fresh ep)) in
    check_valid ep';
    check_same_channel ep.channel ep'.channel;
    result, Obj.magic (fresh ep)
		      
  let select_seq f ep =
    snd (select_seq_bind (fun ep -> (), f ep) ep)

  let accept_seq_bind = select_seq_bind
  let accept_seq = select_seq

  (******************************)
  (*** HIGHER-ORDER ITERATORS ***)
  (******************************)

  let select_iter f =
    let rec aux xs ep =
      match xs with
      | [] -> select_false ep
      | x :: xs ->
	 let ep = select_true ep in
	 let ep = select_seq (f x) ep in
	 aux xs ep
    in aux

  let accept_iter f =
    let rec aux ep =
      match branch ep with
      | `False ep -> ep
      | `True ep -> aux (accept_seq f ep)
    in aux

  let select_map f =
    let rec aux ys xs ep =
      match xs with
      | [] -> List.rev ys, select_false ep
      | x :: xs ->
	 let ep = select_true ep in
	 let y, ep = select_seq_bind (f x) ep in
	 aux (y :: ys) xs ep
    in aux []

  let accept_map f =
    let rec aux xs ep =
      match branch ep with
      | `False ep -> List.rev xs, ep
      | `True ep ->
	 let x, ep = accept_seq_bind f ep in
	 aux (x :: xs) ep
    in aux []

  let select_fold f =
    let rec aux acc xs ep =
      match xs with
      | [] -> acc, select_false ep
      | x :: xs ->
	 let ep = select_true ep in
	 let acc, ep = select_seq_bind (f acc x) ep in
	 aux acc xs ep
    in aux
         
  let accept_fold f =
    let rec aux acc ep =
      match branch ep with
      | `False ep -> acc, ep
      | `True ep ->
	 let acc, ep = accept_seq_bind (f acc) ep in
	 aux acc ep
    in aux
end
    
module Monadic = struct
  type ('t0, 't1, 'a) t = 't0 -> ('a * 't1)

  let (>>=) m f ep = let x, ep = m ep in f x ep
  let (>>>) m1 m2 = m1 >>= fun _ -> m2
  let return m ep = (m, ep)

  let rec fix f = f (fun ep -> fix f ep)

  let connect ms mc =
    let eps, epc = Bare.create () in
    let _ = Thread.create (fun ep -> let (), ep = ms ep in Bare.close ep) eps in
    let x, epc = mc epc in
    Bare.close epc;
    x
      
  let receive = Bare.receive
  let send x ep = let ep = Bare.send x ep in ((), ep)
  let select_true ep = let ep = Bare.select_true ep in ((), ep)
  let select_false ep = let ep = Bare.select_false ep in ((), ep)
  let branch m1 m2 ep =
    match Bare.branch ep with
    | `True ep -> m1 ep
    | `False ep -> m2 ep
end
