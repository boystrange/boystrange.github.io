(* This file is part of FuSe.                                           *)
(*                                                                      *)
(* FuSe is free software: you can redistribute it and/or modify         *)
(* it under the terms of the GNU General Public License as published by *)
(* the Free Software Foundation, either version 3 of the License, or    *)
(* (at your option) any later version.                                  *)
(*                                                                      *)
(* FuSe is distributed in the hope that it will be useful,              *)
(* but WITHOUT ANY WARRANTY; without even the implied warranty of       *)
(* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        *)
(* GNU General Public License for more details.                         *)
(*                                                                      *)
(* You should have received a copy of the GNU General Public License    *)
(* along with FuSe.  If not, see <http://www.gnu.org/licenses/>.        *)
(*                                                                      *)
(* Copyright 2015-2016 Luca Padovani                                    *)

module S = Session.Bare

type 'a tree = Leaf | Node of 'a * 'a tree * 'a tree

let send_tree t0 c =
  let rec aux t c =
    match t with
    | Leaf -> S.select (fun x -> `Leaf x) c
    | Node (v, l, r) ->
       let c = S.select (fun x -> `Node x) c in
       let c = S.send v c in
       let c = aux l c in
       let c = aux r c in c
  in
  S.select (fun x -> `Done x) (aux t0 c)

let receive_tree c =
  let rec aux c =
    match S.branch c with
    | `Leaf c -> Leaf, c
    | `Node c -> let v, c = S.receive c in
		 let l, c = aux c in
		 let r, c = aux c in
		 Node (v, l, r), c
    | _ -> assert false (* impossible *)
  in
  let t, c = aux c in
  match S.branch c with
  | `Done c -> t, c
  | _ -> assert false (* impossible *)
      
let rec send_tree_seq t c =
  match t with
  | Leaf -> S.select (fun x -> `Leaf x) c
  | Node (v, l, r) ->
     let c = S.select (fun x -> `Node x) c in
     let c = S.send v c in
     let c = S.select_seq (send_tree_seq l) c in
     let c = S.select_seq (send_tree_seq r) c in c

let rec receive_tree_seq c =
  match S.branch c with
  | `Leaf c -> Leaf, c
  | `Node c -> let v, c = S.receive c in
	       let l, c = S.accept_seq_bind receive_tree_seq c in
	       let r, c = S.accept_seq_bind receive_tree_seq c in
	       Node (v, l, r), c

let rec transform t c =
  match t with
  | Leaf ->
     Leaf, S.select (fun x -> `Leaf x) c
  | Node (v, l, r) ->
     let c = S.select (fun x -> `Node x) c in
     let c = S.send v c in
     let l', c = S.select_seq_bind (transform l) c in
     let r', c = S.select_seq_bind (transform r) c in
     let v', c = S.receive c in
     Node (v', l', r'), c

let rec tree_sum c =
  match S.branch c with
  | `Leaf c -> 0, c
  | `Node c -> let x, c = S.receive c in
	       let l, c = S.accept_seq_bind tree_sum c in
	       let r, c = S.accept_seq_bind tree_sum c in
	       let c = S.send (x + l + r) c in
	       x + l + r, c

let a_tree = Node (3, Leaf, Node (4, Leaf, Leaf))

let _ =
  let c, s = S.create () in
  let _ = Thread.create tree_sum s in
  transform a_tree c
