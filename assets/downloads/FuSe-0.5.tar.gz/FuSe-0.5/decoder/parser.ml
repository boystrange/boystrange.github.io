type token =
  | LID of (string)
  | CID of (string)
  | LPAREN
  | RPAREN
  | LBRACK
  | RBRACK
  | TICK
  | UNDERSCORE
  | QMARK
  | COLON
  | ARROW
  | STAR
  | COMMA
  | AS
  | OF
  | AND
  | EXCEPTION
  | MODULE
  | TYPE
  | VAL
  | LT
  | GT
  | EQ
  | ELLIPSIS
  | SEMICOLON
  | SHARP
  | DOT
  | OR
  | BACKTICK
  | EOF

open Parsing;;
let _ = parse_error;;
# 19 "parser.mly"
				      let of_tuple_type =
					function
					  [t] -> t
					| ts -> Ast.Constructor (`Tuple, ts)
					
  let syntax_error msg pos =
    let msg' = "syntax error: " ^ msg in
      prerr_endline msg';
      assert false

  let expand t0 =
    let defs = Hashtbl.create 16 in
    let rec collect =
      function
      | Ast.Var _ as t -> t
      | Ast.Tagged (ctor, tags) ->
	 Ast.Tagged (ctor, List.map collect_tag tags)
      | Ast.Constructor (`As x, [t]) ->
	 Hashtbl.add defs x (collect t);
	 Ast.Var x
      | Ast.Constructor (`As _, _) -> assert false (* impossible *)
      | Ast.Constructor (ctor, ts) ->
	 Ast.Constructor (ctor, List.map collect ts)
      | _ -> assert false (* impossible *)
    and collect_tag (name, t) = name, collect t
    in
    let rec aux evars =
      function
      | Ast.Var x when List.mem x evars -> Ast.RecVar x
      | Ast.Var x when Hashtbl.mem defs x ->
	 Ast.Rec (x, aux (x :: evars) (Hashtbl.find defs x))
      | Ast.Var _ as t -> t
      | Ast.Tagged (ctor, tags) ->
	 Ast.Tagged (ctor, List.map (aux_tag evars) tags)
      | Ast.Constructor (ctor, ts) ->
	 Ast.Constructor (ctor, List.map (aux evars) ts)
      | _ -> assert false
    and aux_tag evars (name, t) = (name, aux evars t)
    in aux [] (collect t0)

  let prepend_opt =
    function
    | None -> fun x -> x
    | Some x -> fun y -> x :: y
# 81 "parser.ml"
let yytransl_const = [|
  259 (* LPAREN *);
  260 (* RPAREN *);
  261 (* LBRACK *);
  262 (* RBRACK *);
  263 (* TICK *);
  264 (* UNDERSCORE *);
  265 (* QMARK *);
  266 (* COLON *);
  267 (* ARROW *);
  268 (* STAR *);
  269 (* COMMA *);
  270 (* AS *);
  271 (* OF *);
  272 (* AND *);
  273 (* EXCEPTION *);
  274 (* MODULE *);
  275 (* TYPE *);
  276 (* VAL *);
  277 (* LT *);
  278 (* GT *);
  279 (* EQ *);
  280 (* ELLIPSIS *);
  281 (* SEMICOLON *);
  282 (* SHARP *);
  283 (* DOT *);
  284 (* OR *);
  285 (* BACKTICK *);
    0 (* EOF *);
    0|]

let yytransl_block = [|
  257 (* LID *);
  258 (* CID *);
    0|]

let yylhs = "\255\255\
\001\000\001\000\003\000\003\000\003\000\003\000\003\000\007\000\
\007\000\008\000\009\000\009\000\009\000\006\000\006\000\005\000\
\011\000\011\000\010\000\010\000\012\000\004\000\013\000\013\000\
\014\000\014\000\015\000\015\000\016\000\016\000\016\000\016\000\
\016\000\016\000\016\000\018\000\020\000\020\000\017\000\017\000\
\019\000\019\000\019\000\019\000\021\000\021\000\002\000\002\000\
\023\000\022\000\022\000\000\000"

let yylen = "\002\000\
\001\000\002\000\001\000\004\000\002\000\004\000\002\000\001\000\
\003\000\002\000\000\000\002\000\002\000\001\000\003\000\002\000\
\000\000\002\000\001\000\003\000\002\000\001\000\001\000\003\000\
\001\000\003\000\001\000\003\000\001\000\004\000\003\000\001\000\
\002\000\004\000\001\000\002\000\000\000\002\000\001\000\003\000\
\004\000\004\000\006\000\003\000\000\000\001\000\001\000\003\000\
\004\000\002\000\003\000\002\000"

let yydefred = "\000\000\
\000\000\000\000\039\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\001\000\052\000\000\000\003\000\
\029\000\000\000\023\000\000\000\000\000\032\000\035\000\000\000\
\000\000\000\000\000\000\000\000\000\000\046\000\000\000\000\000\
\021\000\000\000\000\000\005\000\000\000\000\000\007\000\000\000\
\000\000\002\000\000\000\000\000\000\000\033\000\040\000\031\000\
\000\000\036\000\000\000\000\000\000\000\000\000\044\000\000\000\
\000\000\000\000\016\000\000\000\000\000\010\000\000\000\000\000\
\024\000\026\000\028\000\000\000\038\000\034\000\042\000\000\000\
\041\000\000\000\048\000\000\000\018\000\000\000\006\000\000\000\
\012\000\000\000\013\000\009\000\004\000\000\000\000\000\049\000\
\000\000\000\000\000\000\043\000\015\000\020\000\051\000"

let yydgoto = "\002\000\
\014\000\030\000\015\000\016\000\082\000\079\000\039\000\040\000\
\062\000\083\000\059\000\017\000\018\000\019\000\020\000\021\000\
\022\000\026\000\023\000\050\000\031\000\087\000\032\000"

let yysindex = "\009\000\
\165\000\000\000\000\000\247\254\028\255\039\255\023\255\024\255\
\026\255\032\255\028\255\025\255\000\000\000\000\165\000\000\000\
\000\000\022\255\000\000\027\255\010\255\000\000\000\000\012\255\
\004\255\042\255\013\255\013\255\046\255\000\000\043\255\034\255\
\000\000\040\255\036\255\000\000\029\255\031\255\000\000\047\255\
\054\255\000\000\058\255\028\255\028\255\000\000\000\000\000\000\
\028\255\000\000\012\255\253\254\060\255\052\255\000\000\013\255\
\028\255\028\255\000\000\068\255\038\255\000\000\028\255\028\255\
\000\000\000\000\000\000\059\255\000\000\000\000\000\000\044\255\
\000\000\028\255\000\000\012\255\000\000\048\255\000\000\250\254\
\000\000\049\255\000\000\000\000\000\000\069\255\070\255\000\000\
\068\255\026\255\044\255\000\000\000\000\000\000\000\000"

let yyrindex = "\000\000\
\000\000\000\000\000\000\000\000\000\000\072\255\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\055\000\000\000\001\000\081\000\000\000\000\000\000\000\
\000\000\000\000\254\254\072\255\000\000\000\000\000\000\001\255\
\000\000\000\000\105\000\000\000\000\000\125\000\000\000\185\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\075\255\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\027\000\000\000\205\000\000\000\105\000\
\000\000\145\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\074\255\000\000\000\000\000\000\000\000"

let yygindex = "\000\000\
\059\000\026\000\000\000\251\255\074\000\252\255\021\000\000\000\
\000\000\253\255\000\000\043\000\000\000\044\000\045\000\032\000\
\237\255\042\000\000\000\000\000\244\255\002\000\000\000"

let yytablesize = 481
let yytable = "\025\000\
\025\000\046\000\071\000\045\000\047\000\038\000\047\000\048\000\
\058\000\001\000\003\000\004\000\003\000\004\000\052\000\053\000\
\049\000\024\000\072\000\045\000\024\000\045\000\047\000\033\000\
\034\000\041\000\030\000\035\000\003\000\004\000\005\000\070\000\
\006\000\037\000\007\000\043\000\008\000\044\000\003\000\080\000\
\005\000\029\000\006\000\068\000\007\000\051\000\008\000\054\000\
\055\000\057\000\058\000\060\000\077\000\061\000\022\000\081\000\
\046\000\038\000\085\000\027\000\028\000\056\000\063\000\064\000\
\007\000\073\000\074\000\029\000\088\000\078\000\091\000\049\000\
\086\000\042\000\089\000\092\000\090\000\045\000\037\000\050\000\
\027\000\075\000\036\000\084\000\093\000\065\000\094\000\066\000\
\076\000\067\000\069\000\000\000\095\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\017\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\011\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\019\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\013\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\008\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\014\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\025\000\025\000\025\000\025\000\025\000\025\000\025\000\
\000\000\025\000\000\000\000\000\000\000\025\000\025\000\000\000\
\025\000\025\000\025\000\025\000\025\000\000\000\025\000\025\000\
\000\000\000\000\000\000\000\000\025\000\030\000\030\000\030\000\
\030\000\030\000\000\000\030\000\000\000\030\000\030\000\030\000\
\030\000\000\000\030\000\030\000\030\000\030\000\030\000\000\000\
\030\000\030\000\000\000\000\000\000\000\000\000\030\000\022\000\
\022\000\022\000\022\000\022\000\022\000\022\000\000\000\022\000\
\000\000\000\000\000\000\022\000\000\000\000\000\022\000\022\000\
\022\000\022\000\022\000\000\000\022\000\022\000\000\000\000\000\
\000\000\000\000\022\000\027\000\027\000\027\000\027\000\027\000\
\000\000\027\000\000\000\027\000\000\000\027\000\027\000\000\000\
\027\000\027\000\027\000\027\000\027\000\000\000\027\000\027\000\
\000\000\017\000\017\000\017\000\027\000\017\000\000\000\017\000\
\000\000\017\000\000\000\000\000\000\000\000\000\000\000\000\000\
\017\000\017\000\017\000\017\000\017\000\011\000\011\000\011\000\
\000\000\011\000\000\000\011\000\017\000\011\000\000\000\000\000\
\000\000\000\000\000\000\000\000\011\000\011\000\011\000\011\000\
\011\000\019\000\019\000\019\000\000\000\019\000\000\000\019\000\
\000\000\019\000\000\000\000\000\000\000\000\000\000\000\000\000\
\019\000\019\000\019\000\019\000\019\000\003\000\004\000\005\000\
\000\000\006\000\000\000\007\000\000\000\008\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\009\000\010\000\011\000\
\012\000\008\000\008\000\008\000\000\000\008\000\000\000\008\000\
\000\000\008\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\008\000\008\000\008\000\008\000\014\000\014\000\014\000\
\000\000\014\000\000\000\014\000\000\000\014\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\014\000\014\000\014\000\
\014\000"

let yycheck = "\005\000\
\000\000\021\000\006\001\006\001\024\000\011\000\006\001\004\001\
\015\001\001\000\001\001\002\001\001\001\002\001\027\000\028\000\
\013\001\027\001\022\001\022\001\027\001\012\001\022\001\001\001\
\001\001\001\001\000\000\002\001\001\001\002\001\003\001\051\000\
\005\001\002\001\007\001\014\001\009\001\011\001\001\001\002\001\
\003\001\029\001\005\001\049\000\007\001\004\001\009\001\002\001\
\006\001\010\001\015\001\023\001\058\000\023\001\000\000\061\000\
\076\000\063\000\064\000\021\001\022\001\028\001\016\001\010\001\
\007\001\006\001\015\001\029\001\074\000\002\001\002\001\013\001\
\029\001\015\000\027\001\006\001\028\001\006\001\004\001\006\001\
\000\000\056\000\009\000\063\000\089\000\043\000\090\000\044\000\
\057\000\045\000\049\000\255\255\091\000\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\000\000\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\000\000\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\000\000\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\000\000\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\000\000\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\000\000\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\001\001\002\001\003\001\004\001\005\001\006\001\007\001\
\255\255\009\001\255\255\255\255\255\255\013\001\014\001\255\255\
\016\001\017\001\018\001\019\001\020\001\255\255\022\001\023\001\
\255\255\255\255\255\255\255\255\028\001\003\001\004\001\005\001\
\006\001\007\001\255\255\009\001\255\255\011\001\012\001\013\001\
\014\001\255\255\016\001\017\001\018\001\019\001\020\001\255\255\
\022\001\023\001\255\255\255\255\255\255\255\255\028\001\001\001\
\002\001\003\001\004\001\005\001\006\001\007\001\255\255\009\001\
\255\255\255\255\255\255\013\001\255\255\255\255\016\001\017\001\
\018\001\019\001\020\001\255\255\022\001\023\001\255\255\255\255\
\255\255\255\255\028\001\003\001\004\001\005\001\006\001\007\001\
\255\255\009\001\255\255\011\001\255\255\013\001\014\001\255\255\
\016\001\017\001\018\001\019\001\020\001\255\255\022\001\023\001\
\255\255\001\001\002\001\003\001\028\001\005\001\255\255\007\001\
\255\255\009\001\255\255\255\255\255\255\255\255\255\255\255\255\
\016\001\017\001\018\001\019\001\020\001\001\001\002\001\003\001\
\255\255\005\001\255\255\007\001\028\001\009\001\255\255\255\255\
\255\255\255\255\255\255\255\255\016\001\017\001\018\001\019\001\
\020\001\001\001\002\001\003\001\255\255\005\001\255\255\007\001\
\255\255\009\001\255\255\255\255\255\255\255\255\255\255\255\255\
\016\001\017\001\018\001\019\001\020\001\001\001\002\001\003\001\
\255\255\005\001\255\255\007\001\255\255\009\001\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\017\001\018\001\019\001\
\020\001\001\001\002\001\003\001\255\255\005\001\255\255\007\001\
\255\255\009\001\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\017\001\018\001\019\001\020\001\001\001\002\001\003\001\
\255\255\005\001\255\255\007\001\255\255\009\001\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\017\001\018\001\019\001\
\020\001"

let yynames_const = "\
  LPAREN\000\
  RPAREN\000\
  LBRACK\000\
  RBRACK\000\
  TICK\000\
  UNDERSCORE\000\
  QMARK\000\
  COLON\000\
  ARROW\000\
  STAR\000\
  COMMA\000\
  AS\000\
  OF\000\
  AND\000\
  EXCEPTION\000\
  MODULE\000\
  TYPE\000\
  VAL\000\
  LT\000\
  GT\000\
  EQ\000\
  ELLIPSIS\000\
  SEMICOLON\000\
  SHARP\000\
  DOT\000\
  OR\000\
  BACKTICK\000\
  EOF\000\
  "

let yynames_block = "\
  LID\000\
  CID\000\
  "

let yyact = [|
  (fun _ -> failwith "parser")
; (fun __caml_parser_env ->
    Obj.repr(
# 107 "parser.mly"
      ( [] )
# 357 "parser.ml"
               : Specification.t list))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : 'specification) in
    let _2 = (Parsing.peek_val __caml_parser_env 0 : Specification.t list) in
    Obj.repr(
# 108 "parser.mly"
                     ( prepend_opt _1 _2 )
# 365 "parser.ml"
               : Specification.t list))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'type_expr) in
    Obj.repr(
# 112 "parser.mly"
            ( Some (Specification.Type (expand _1)) )
# 372 "parser.ml"
               : 'specification))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 2 : string) in
    let _4 = (Parsing.peek_val __caml_parser_env 0 : 'type_expr) in
    Obj.repr(
# 113 "parser.mly"
                          ( Some (Specification.Val (_2, expand _4)) )
# 380 "parser.ml"
               : 'specification))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'constr_decl) in
    Obj.repr(
# 114 "parser.mly"
                        ( None )
# 387 "parser.ml"
               : 'specification))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 2 : string) in
    let _4 = (Parsing.peek_val __caml_parser_env 0 : 'module_path) in
    Obj.repr(
# 115 "parser.mly"
                            ( None )
# 395 "parser.ml"
               : 'specification))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'type_definition_ne_list) in
    Obj.repr(
# 116 "parser.mly"
                               ( None )
# 402 "parser.ml"
               : 'specification))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'type_definition) in
    Obj.repr(
# 120 "parser.mly"
                  ( )
# 409 "parser.ml"
               : 'type_definition_ne_list))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'type_definition) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'type_definition_ne_list) in
    Obj.repr(
# 121 "parser.mly"
                                              ( )
# 417 "parser.ml"
               : 'type_definition_ne_list))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : 'type_expr) in
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'type_information) in
    Obj.repr(
# 125 "parser.mly"
                             ( )
# 425 "parser.ml"
               : 'type_definition))
; (fun __caml_parser_env ->
    Obj.repr(
# 129 "parser.mly"
  ( )
# 431 "parser.ml"
               : 'type_information))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'type_expr) in
    Obj.repr(
# 130 "parser.mly"
               ( )
# 438 "parser.ml"
               : 'type_information))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'constr_decl_ne_list) in
    Obj.repr(
# 131 "parser.mly"
                         ( )
# 445 "parser.ml"
               : 'type_information))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : string) in
    Obj.repr(
# 135 "parser.mly"
      ( )
# 452 "parser.ml"
               : 'module_path))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : string) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'module_path) in
    Obj.repr(
# 136 "parser.mly"
                      ( )
# 460 "parser.ml"
               : 'module_path))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : string) in
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'constr_args_opt) in
    Obj.repr(
# 140 "parser.mly"
                      ( )
# 468 "parser.ml"
               : 'constr_decl))
; (fun __caml_parser_env ->
    Obj.repr(
# 144 "parser.mly"
  ( )
# 474 "parser.ml"
               : 'constr_args_opt))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'type_expr) in
    Obj.repr(
# 145 "parser.mly"
               ( )
# 481 "parser.ml"
               : 'constr_args_opt))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'constr_decl) in
    Obj.repr(
# 149 "parser.mly"
              ( )
# 488 "parser.ml"
               : 'constr_decl_ne_list))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'constr_decl) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'constr_decl_ne_list) in
    Obj.repr(
# 150 "parser.mly"
                                     ( )
# 496 "parser.ml"
               : 'constr_decl_ne_list))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 0 : string) in
    Obj.repr(
# 154 "parser.mly"
           ( _2 )
# 503 "parser.ml"
               : 'type_var))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'as_type_expr) in
    Obj.repr(
# 158 "parser.mly"
               ( _1 )
# 510 "parser.ml"
               : 'type_expr))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'arrow_type_expr) in
    Obj.repr(
# 162 "parser.mly"
                  ( _1 )
# 517 "parser.ml"
               : 'as_type_expr))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'as_type_expr) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'type_var) in
    Obj.repr(
# 163 "parser.mly"
                           ( Ast.Constructor (`As _3, [_1]) )
# 525 "parser.ml"
               : 'as_type_expr))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'tuple_type_expr) in
    Obj.repr(
# 167 "parser.mly"
                  ( of_tuple_type _1 )
# 532 "parser.ml"
               : 'arrow_type_expr))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'tuple_type_expr) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'arrow_type_expr) in
    Obj.repr(
# 169 "parser.mly"
  ( Ast.Constructor (`Arrow, [of_tuple_type _1; _3]) )
# 540 "parser.ml"
               : 'arrow_type_expr))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'atomic_type_expr) in
    Obj.repr(
# 173 "parser.mly"
                   ( [_1] )
# 547 "parser.ml"
               : 'tuple_type_expr))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'atomic_type_expr) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'tuple_type_expr) in
    Obj.repr(
# 174 "parser.mly"
                                        ( _1 :: _3 )
# 555 "parser.ml"
               : 'tuple_type_expr))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'type_var) in
    Obj.repr(
# 178 "parser.mly"
           ( Ast.Var _1 )
# 562 "parser.ml"
               : 'atomic_type_expr))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 2 : string) in
    let _4 = (Parsing.peek_val __caml_parser_env 0 : 'atomic_type_expr) in
    Obj.repr(
# 179 "parser.mly"
                                   ( _4 )
# 570 "parser.ml"
               : 'atomic_type_expr))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 1 : 'type_expr) in
    Obj.repr(
# 180 "parser.mly"
                          ( _2 )
# 577 "parser.ml"
               : 'atomic_type_expr))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'type_constr) in
    Obj.repr(
# 181 "parser.mly"
              ( Ast.Constructor (`Apply _1, []) )
# 584 "parser.ml"
               : 'atomic_type_expr))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : 'atomic_type_expr) in
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'type_constr) in
    Obj.repr(
# 182 "parser.mly"
                               ( Ast.Constructor (`Apply _2, [_1]) )
# 592 "parser.ml"
               : 'atomic_type_expr))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 2 : 'type_expr_comma_ne_list) in
    let _4 = (Parsing.peek_val __caml_parser_env 0 : 'type_constr) in
    Obj.repr(
# 183 "parser.mly"
                                                    ( Ast.Constructor (`Apply _4, _2) )
# 600 "parser.ml"
               : 'atomic_type_expr))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'polymorphic_variant_type) in
    Obj.repr(
# 184 "parser.mly"
                           ( Ast.Tagged (`Variant, _1) )
# 607 "parser.ml"
               : 'atomic_type_expr))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : 'type_expr) in
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'comma_type_expr_list) in
    Obj.repr(
# 188 "parser.mly"
                                 ( _1 :: _2 )
# 615 "parser.ml"
               : 'type_expr_comma_ne_list))
; (fun __caml_parser_env ->
    Obj.repr(
# 192 "parser.mly"
  ( [] )
# 621 "parser.ml"
               : 'comma_type_expr_list))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'type_expr_comma_ne_list) in
    Obj.repr(
# 193 "parser.mly"
                                ( _2 )
# 628 "parser.ml"
               : 'comma_type_expr_list))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : string) in
    Obj.repr(
# 197 "parser.mly"
      ( [_1] )
# 635 "parser.ml"
               : 'type_constr))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : string) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'type_constr) in
    Obj.repr(
# 198 "parser.mly"
                      ( _1 :: _3 )
# 643 "parser.ml"
               : 'type_constr))
; (fun __caml_parser_env ->
    let _3 = (Parsing.peek_val __caml_parser_env 1 : 'tag_spec_list) in
    Obj.repr(
# 202 "parser.mly"
                                 ( _3 )
# 650 "parser.ml"
               : 'polymorphic_variant_type))
; (fun __caml_parser_env ->
    let _3 = (Parsing.peek_val __caml_parser_env 1 : 'tag_spec_list) in
    Obj.repr(
# 203 "parser.mly"
                                 ( _3 )
# 657 "parser.ml"
               : 'polymorphic_variant_type))
; (fun __caml_parser_env ->
    let _3 = (Parsing.peek_val __caml_parser_env 3 : 'tag_spec_list) in
    let _5 = (Parsing.peek_val __caml_parser_env 1 : 'tag_ne_list) in
    Obj.repr(
# 204 "parser.mly"
                                                ( _3 )
# 665 "parser.ml"
               : 'polymorphic_variant_type))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 1 : 'tag_spec_list) in
    Obj.repr(
# 205 "parser.mly"
                              ( _2 )
# 672 "parser.ml"
               : 'polymorphic_variant_type))
; (fun __caml_parser_env ->
    Obj.repr(
# 209 "parser.mly"
  ( [] )
# 678 "parser.ml"
               : 'tag_spec_list))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : (string * Ast.t) list) in
    Obj.repr(
# 210 "parser.mly"
                   ( _1 )
# 685 "parser.ml"
               : 'tag_spec_list))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'tag_spec) in
    Obj.repr(
# 214 "parser.mly"
           ( [_1] )
# 692 "parser.ml"
               : (string * Ast.t) list))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'tag_spec) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : (string * Ast.t) list) in
    Obj.repr(
# 215 "parser.mly"
                               ( _1 :: _3 )
# 700 "parser.ml"
               : (string * Ast.t) list))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 2 : string) in
    let _4 = (Parsing.peek_val __caml_parser_env 0 : 'type_expr) in
    Obj.repr(
# 219 "parser.mly"
                            ( (_2, _4) )
# 708 "parser.ml"
               : 'tag_spec))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 0 : string) in
    Obj.repr(
# 223 "parser.mly"
               ( )
# 715 "parser.ml"
               : 'tag_ne_list))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 1 : string) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'tag_ne_list) in
    Obj.repr(
# 224 "parser.mly"
                           ( )
# 723 "parser.ml"
               : 'tag_ne_list))
(* Entry main *)
; (fun __caml_parser_env -> raise (Parsing.YYexit (Parsing.peek_val __caml_parser_env 0)))
|]
let yytables =
  { Parsing.actions=yyact;
    Parsing.transl_const=yytransl_const;
    Parsing.transl_block=yytransl_block;
    Parsing.lhs=yylhs;
    Parsing.len=yylen;
    Parsing.defred=yydefred;
    Parsing.dgoto=yydgoto;
    Parsing.sindex=yysindex;
    Parsing.rindex=yyrindex;
    Parsing.gindex=yygindex;
    Parsing.tablesize=yytablesize;
    Parsing.table=yytable;
    Parsing.check=yycheck;
    Parsing.error_function=parse_error;
    Parsing.names_const=yynames_const;
    Parsing.names_block=yynames_block }
let main (lexfun : Lexing.lexbuf -> token) (lexbuf : Lexing.lexbuf) =
   (Parsing.yyparse yytables 1 lexfun lexbuf : Specification.t list)
;;
