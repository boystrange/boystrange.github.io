(* This file is part of FuSe.                                           *)
(*                                                                      *)
(* FuSe is free software: you can redistribute it and/or modify         *)
(* it under the terms of the GNU General Public License as published by *)
(* the Free Software Foundation, either version 3 of the License, or    *)
(* (at your option) any later version.                                  *)
(*                                                                      *)
(* FuSe is distributed in the hope that it will be useful,              *)
(* but WITHOUT ANY WARRANTY; without even the implied warranty of       *)
(* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        *)
(* GNU General Public License for more details.                         *)
(*                                                                      *)
(* You should have received a copy of the GNU General Public License    *)
(* along with FuSe.  If not, see <http://www.gnu.org/licenses/>.        *)
(*                                                                      *)
(* Copyright 2015-2016 Luca Padovani                                    *)

let rec range m n =
  if m > n then [] else m :: range (m + 1) n

let string_of_list xs =
  "[" ^ String.concat ", " (List.map string_of_int xs) ^ "]"
       
let server1 a =
  Session.close
    (Session.receive_all
       a
       (fun ep ->
         let x, ep = Session.receive ep in
         print_endline ("received " ^ string_of_int x);
         ep))

let client1 b n =
  Session.close (Session.send_all b Session.send (range 1 n))

let server2 a =
  Session.close
    (Session.receive_all
       a
       (fun ep ->
         let x, ep = Session.receive ep in
         Session.send ep (x * x)))

let client2 b n =
  Session.close
    (Session.send_all
       b
       (fun ep x ->
         let ep = Session.send ep x in
         let y, ep = Session.receive ep in
         print_endline ("sent " ^ string_of_int x ^ " and received " ^ string_of_int y);
         ep)
       (range 1 n))

let server3 a =
  let xs, a = Session.receive_map a Session.receive in
  print_endline (string_of_list xs);
  Session.close a

let server4 a =
  let s, a =
    Session.receive_fold
      a (fun ep s -> let x, ep = Session.receive ep in (s + x), ep) 0
  in print_endline (string_of_int s);
     Session.close a

let client3 ep n =
  let s, ep = Session.send_fold
                ep
                (fun ep x acc -> let ep = Session.send ep x in
                                 let y, ep = Session.receive ep in
                                 (acc + y), ep)
                0
                (range 1 n)
  in print_endline (string_of_int s);
     Session.close ep
                   
let _ =
  client1 (Service.request (Service.spawn server1)) 10;
  client2 (Service.request (Service.spawn server2)) 10;
  client1 (Service.request (Service.spawn server3)) 10;
  client1 (Service.request (Service.spawn server4)) 10;
  client3 (Service.request (Service.spawn server2)) 10;
