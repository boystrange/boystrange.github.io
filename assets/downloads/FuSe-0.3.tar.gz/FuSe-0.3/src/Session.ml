(* This file is part of FuSe.                                           *)
(*                                                                      *)
(* FuSe is free software: you can redistribute it and/or modify         *)
(* it under the terms of the GNU General Public License as published by *)
(* the Free Software Foundation, either version 3 of the License, or    *)
(* (at your option) any later version.                                  *)
(*                                                                      *)
(* FuSe is distributed in the hope that it will be useful,              *)
(* but WITHOUT ANY WARRANTY; without even the implied warranty of       *)
(* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        *)
(* GNU General Public License for more details.                         *)
(*                                                                      *)
(* You should have received a copy of the GNU General Public License    *)
(* along with FuSe.  If not, see <http://www.gnu.org/licenses/>.        *)
(*                                                                      *)
(* Copyright 2015-2016 Luca Padovani                                    *)

exception InvalidEndpoint

type _0
type ('a, 'b) star_t = More of 'a | Done of 'b
type ('a, 'b, 'c, 'd) st
type (+'a, -'b) t = unit Event.channel * bool ref
type et           = (_0, _0) t
type +'a it       = ('a, _0) t
type -'a ot       = (_0, 'a) t

let fresh u  = (u, ref true)
let check r = if !r then r := false else raise InvalidEndpoint
let check_same_channel (u, _) (v, _) =
  if Obj.magic u == v then () else raise InvalidEndpoint

let create () =
  let ch = Event.new_channel () in (fresh ch, fresh ch)
let close (_, r) = check r

let send (u, r) x =
  check r;
  Event.sync (Event.send u (Obj.magic x));
  Obj.magic (fresh u)
	    
let receive (u, r) =
  check r;
  Obj.magic (Event.sync (Event.receive u), fresh u)

let select = send
let left u = select u (fun x -> `L x)
let right u = select u (fun x -> `R x)
let branch (u, r) =
  check r;
  Obj.magic (Event.sync (Event.receive u)) (fresh u)

let is_valid (_, r) = !r
                       
let acquire (u, r) =
  check r;
  fresh u

let try_acquire (u, r) =
  if !r then
    begin
      r := false;
      Some (fresh u)
    end
  else
    None
      
let iterate_done (u, r) =
  check r;
  Event.sync (Event.send u (Obj.magic false));
  Obj.magic (fresh u)

let iterate_map (u, r) f =
  check r;
  Event.sync (Event.send u (Obj.magic true));
  let result, (v, s) = f (Obj.magic (fresh u)) in
  check s;
  (if not (Obj.magic u == v) then raise InvalidEndpoint);
  result, Obj.magic (fresh u)

let iterate_more ep f =
  snd (iterate_map ep (fun ep -> (), f ep))

let iterate_branch (u, r) =
  check r;
  if Obj.magic (Event.sync (Event.receive u)) then
    More (Obj.magic (fresh u))
  else
    Done (Obj.magic (fresh u))

let send_all ep f =
  let rec aux ep =
    function
      [] -> iterate_done ep
    | x :: xs -> let ep = iterate_more ep (fun ep -> f ep x) in
                 aux ep xs
  in aux ep

let receive_all ep f =
  let rec aux ep =
    match iterate_branch ep with
      Done ep -> ep
    | More ep -> let ep' = f ep in
                 check_same_channel ep' ep;
                 aux ep'
  in aux ep

let send_map ep f =
  let rec aux ep ys =
    function
      [] -> List.rev ys, iterate_done ep
    | x :: xs -> let y, ep = iterate_map ep (fun ep -> f ep x) in
                 aux ep (y :: ys) xs
  in aux ep []

let receive_map ep f =
  let rec aux ep xs =
    match iterate_branch ep with
      Done ep -> List.rev xs, ep
    | More ep -> let x, ep' = f ep in
                 check_same_channel ep' ep;
                 aux ep' (x :: xs)
  in aux ep []

let send_fold ep f =
  let rec aux ep acc =
    function
      [] -> acc, iterate_done ep
    | x :: xs -> let acc, ep = iterate_map ep (fun ep -> f ep acc x) in
                 aux ep acc xs
  in aux ep
            
let receive_fold ep f =
  let rec aux ep a =
    match iterate_branch ep with
      Done ep -> a, ep
    | More ep -> let a, ep' = f ep a in
                 check_same_channel ep' ep;
                 aux ep' a
  in aux ep
