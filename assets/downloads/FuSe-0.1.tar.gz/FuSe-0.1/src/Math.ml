(* This file is part of FuSe.                                           *)
(*                                                                      *)
(* FuSe is free software: you can redistribute it and/or modify         *)
(* it under the terms of the GNU General Public License as published by *)
(* the Free Software Foundation, either version 3 of the License, or    *)
(* (at your option) any later version.                                  *)
(*                                                                      *)
(* FuSe is distributed in the hope that it will be useful,              *)
(* but WITHOUT ANY WARRANTY; without even the implied warranty of       *)
(* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        *)
(* GNU General Public License for more details.                         *)
(*                                                                      *)
(* You should have received a copy of the GNU General Public License    *)
(* along with FuSe.  If not, see <http://www.gnu.org/licenses/>.        *)
(*                                                                      *)
(* Copyright 2015 Luca Padovani                                         *)

let rec server s =
  match Session.branch s with
    `Quit s -> Session.close s
  | `Plus s -> let n, s = Session.receive s in
	       let m, s = Session.receive s in
	       let s = Session.send s (n + m) in
	       server s
  | `Mult s -> let n, s = Session.receive s in
	       let m, s = Session.receive s in
	       let s = Session.send s (n * m) in
	       server s
  | `Neg s  -> let n, s = Session.receive s in
	       let s = Session.send s (-n) in
	       server s
  | `Eq s   -> let n, s = Session.receive s in
	       let m, s = Session.receive s in
	       let s = Session.send s (n = m) in
	       server s

let client n s =
  let rec aux acc n s =
    if n = 0 then
      let s = Session.select s (fun x -> `Quit x) in
      Session.close s; acc
    else
      let s = Session.select s (fun x -> `Mult x) in
      let s = Session.send s acc in
      let s = Session.send s n in
      let res, s = Session.receive s in
      aux res (n - 1) s
  in aux 1 n s

let _ =
  let ch = Service.spawn server in
  print_int (client 10 (Service.request ch))

