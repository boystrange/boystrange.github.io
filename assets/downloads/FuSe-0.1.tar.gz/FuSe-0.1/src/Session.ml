(* This file is part of FuSe.                                           *)
(*                                                                      *)
(* FuSe is free software: you can redistribute it and/or modify         *)
(* it under the terms of the GNU General Public License as published by *)
(* the Free Software Foundation, either version 3 of the License, or    *)
(* (at your option) any later version.                                  *)
(*                                                                      *)
(* FuSe is distributed in the hope that it will be useful,              *)
(* but WITHOUT ANY WARRANTY; without even the implied warranty of       *)
(* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        *)
(* GNU General Public License for more details.                         *)
(*                                                                      *)
(* You should have received a copy of the GNU General Public License    *)
(* along with FuSe.  If not, see <http://www.gnu.org/licenses/>.        *)
(*                                                                      *)
(* Copyright 2015 Luca Padovani                                         *)

exception InvalidEndpoint

type _0
type _1
type ('a, 'b, 'm) t = 'm Event.channel * bool ref

let compare_and_swap r v w = if !r = v then begin r := w; true end else false
let fresh u  = (u, ref true)
let check r = if not (compare_and_swap r true false) then raise InvalidEndpoint

let create () = let ch = Event.new_channel () in (fresh ch, fresh ch)

let close (_, r) = check r

let send (u, r) x = check r; Event.sync (Event.send u (Obj.magic x)); Obj.magic (fresh u)

let receive (u, r) = check r; Obj.magic (Event.sync (Event.receive u), fresh u)

let select = send
let left u = select u (fun x -> `L x)
let right u = select u (fun x -> `R x)

let branch (u, r)  = check r; Obj.magic (Event.sync (Event.receive u)) (fresh u)

let acquire (u, r) = check r; fresh u
