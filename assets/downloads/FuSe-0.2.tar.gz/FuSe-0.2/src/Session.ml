(* This file is part of FuSe.                                           *)
(*                                                                      *)
(* FuSe is free software: you can redistribute it and/or modify         *)
(* it under the terms of the GNU General Public License as published by *)
(* the Free Software Foundation, either version 3 of the License, or    *)
(* (at your option) any later version.                                  *)
(*                                                                      *)
(* FuSe is distributed in the hope that it will be useful,              *)
(* but WITHOUT ANY WARRANTY; without even the implied warranty of       *)
(* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        *)
(* GNU General Public License for more details.                         *)
(*                                                                      *)
(* You should have received a copy of the GNU General Public License    *)
(* along with FuSe.  If not, see <http://www.gnu.org/licenses/>.        *)
(*                                                                      *)
(* Copyright 2015-2016 Luca Padovani                                    *)

exception InvalidEndpoint

type _0
type _1
type ('a, 'b) _STAR
type (+'a, -'b) t = unit Event.channel * bool ref
type et           = (_0, _0) t
type +'a it       = ('a, _0) t
type -'a ot       = (_0, 'a) t

let fresh u  = (u, ref true)
let check r = if !r then r := false else raise InvalidEndpoint

let create () =
  let ch = Event.new_channel () in (fresh ch, fresh ch)
let close (_, r) = check r

let send (u, r) x =
  check r;
  Event.sync (Event.send u (Obj.magic x));
  Obj.magic (fresh u)
	    
let receive (u, r) =
  check r;
  Obj.magic (Event.sync (Event.receive u), fresh u)

let select = send
let left u = select u (fun x -> `L x)
let right u = select u (fun x -> `R x)
let branch (u, r) =
  check r;
  Obj.magic (Event.sync (Event.receive u)) (fresh u)

let acquire (u, r) =
  check r;
  fresh u

let iterate (u, r) f =
  check r;
  let rec aux () =
    if Obj.magic (Event.sync (Event.receive u)) then
      let (v, s) = f (Obj.magic (fresh u)) in
      check s;
      (if not (Obj.magic u == v) then raise InvalidEndpoint);
      aux ()
    else
      Obj.magic (fresh u)
  in
  aux ()

let skip (u, r) =
  check r;
  Event.sync (Event.send u (Obj.magic false));
  Obj.magic (fresh u)

let more (u, r) f =
  check r;
  Event.sync (Event.send u (Obj.magic true));
  let (v, s) = f (Obj.magic (fresh u)) in
  check s;
  (if not (Obj.magic u == v) then raise InvalidEndpoint);
  Obj.magic (fresh u)
