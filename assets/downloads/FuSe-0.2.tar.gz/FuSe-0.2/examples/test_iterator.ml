(* This file is part of FuSe.                                           *)
(*                                                                      *)
(* FuSe is free software: you can redistribute it and/or modify         *)
(* it under the terms of the GNU General Public License as published by *)
(* the Free Software Foundation, either version 3 of the License, or    *)
(* (at your option) any later version.                                  *)
(*                                                                      *)
(* FuSe is distributed in the hope that it will be useful,              *)
(* but WITHOUT ANY WARRANTY; without even the implied warranty of       *)
(* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        *)
(* GNU General Public License for more details.                         *)
(*                                                                      *)
(* You should have received a copy of the GNU General Public License    *)
(* along with FuSe.  If not, see <http://www.gnu.org/licenses/>.        *)
(*                                                                      *)
(* Copyright 2015-2016 Luca Padovani                                    *)

let server a =
  Session.close
    (Session.iterate a (fun a ->
		       let n, a = Session.receive a in
		       Session.send a (n * n)))

let rec client b n =
  if n = 0 then
    let b = Session.skip b in
    Session.close b
  else
    client 
      (Session.more b (fun b -> 
		      let b = Session.send b n in
		      let res, b = Session.receive b in
		      print_endline (string_of_int res); b)) (n - 1)

let _ =
  let ch = Service.spawn server in
  client (Service.request ch) 100
      
