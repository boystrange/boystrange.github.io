(* This file is part of FuSe.                                           *)
(*                                                                      *)
(* FuSe is free software: you can redistribute it and/or modify         *)
(* it under the terms of the GNU General Public License as published by *)
(* the Free Software Foundation, either version 3 of the License, or    *)
(* (at your option) any later version.                                  *)
(*                                                                      *)
(* FuSe is distributed in the hope that it will be useful,              *)
(* but WITHOUT ANY WARRANTY; without even the implied warranty of       *)
(* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        *)
(* GNU General Public License for more details.                         *)
(*                                                                      *)
(* You should have received a copy of the GNU General Public License    *)
(* along with FuSe.  If not, see <http://www.gnu.org/licenses/>.        *)
(*                                                                      *)
(* Copyright 2015-2016 Luca Padovani                                    *)

exception InvalidEndpoint
exception UnusedValidEndpoint
            
type _0
type (+'a, -'b) st = unit Event.channel * bool ref
type et            = (_0, _0) st
type +'a it        = ('a, _0) st
type -'a ot        = (_0, 'a) st
type ('a, 'b) seq
type 'a istar = [ `Done of et | `More of ('a, 'b) seq it ] it as 'b
type 'a ostar = [ `Done of et | `More of ('a, 'b) seq ot ] ot as 'b
			      
let check_valid r = if !r then r := false else raise InvalidEndpoint
let same_channel u v = Obj.magic u == v
let check_same_channel u v =
  if same_channel u v then () else raise InvalidEndpoint
let check_invalid (_, r) = if !r then raise UnusedValidEndpoint
                   
let fresh u =
  let ep = (u, ref true) in
  Gc.finalise check_invalid ep;
  ep

(*********************************************)
(*** INITIATION, IDENTITY, AND TERMINATION ***)
(*********************************************)
    
let create () =
  let ch = Event.new_channel () in (fresh ch, fresh ch)
let close (_, r) = check_valid r

let send (u, r) x =
  check_valid r;
  Event.sync (Event.send u (Obj.magic x));
  Obj.magic (fresh u)

let same_session (u, _) (v, _) = same_channel u v
		     
(*************************************)
(*** MESSAGE PASSING AND BRANCHING ***)
(*************************************)
		     
let receive (u, r) =
  check_valid r;
  Obj.magic (Event.sync (Event.receive u), fresh u)

let select = send
let left u = select u (fun x -> `L x)
let right u = select u (fun x -> `R x)
let branch (u, r) =
  check_valid r;
  Obj.magic (Event.sync (Event.receive u)) (fresh u)

(*****************)
(*** LINEARITY ***)
(*****************)
	    
let is_valid (_, r) = !r
                       
let acquire (u, r) =
  check_valid r;
  fresh u

let try_acquire (u, r) =
  if !r then
    begin
      r := false;
      Some (fresh u)
    end
  else
    None

(******************************)      
(*** SEQUENTIAL COMPOSITION ***)
(******************************)      

let seq_select_bind (u, r) f =
  check_valid r;
  let result, (v, s) = f (Obj.magic (fresh u)) in
  check_valid s;
  check_same_channel u v;
  result, Obj.magic (fresh u)
  
let seq_select ep f =
  snd (seq_select_bind ep (fun ep -> (), f ep))
    
let seq_branch_bind = seq_select_bind
let seq_branch = seq_select

(***************************)
(*** LOW-LEVEL ITERATORS ***)
(***************************)
			    
let select_Done ep = select ep (fun x -> `Done x)
let select_More ep = select ep (fun x -> `More x)

(******************************)
(*** HIGHER-ORDER ITERATORS ***)
(******************************)
		    
let iter_select ep f =
  let rec aux ep =
    function
      [] -> select_Done ep
    | x :: xs -> let ep = select_More ep in
		 let ep = seq_select ep (fun ep -> f ep x) in
                 aux ep xs
  in aux ep

let iter_branch ep f =
  let rec aux ep =
    match branch ep with
      `Done ep -> ep
    | `More ep -> aux (seq_branch ep f)
  in aux ep

let map_select ep f =
  let rec aux ep ys =
    function
      [] -> List.rev ys, select_Done ep
    | x :: xs -> let ep = select_More ep in
		 let y, ep = seq_select_bind ep (fun ep -> f ep x) in
                 aux ep (y :: ys) xs
  in aux ep []

let map_branch ep f =
  let rec aux ep xs =
    match branch ep with
      `Done ep -> List.rev xs, ep
    | `More ep -> let x, ep = seq_branch_bind ep f in
                  aux ep (x :: xs)
  in aux ep []

let fold_select ep f =
  let rec aux ep acc =
    function
      [] -> acc, select_Done ep
    | x :: xs -> let ep = select_More ep in
		 let acc, ep = seq_select_bind ep (fun ep -> f ep acc x) in
		 aux ep acc xs
  in aux ep
            
let fold_branch ep f =
  let rec aux ep acc =
    match branch ep with
      `Done ep -> acc, ep
    | `More ep -> let acc, ep = seq_branch_bind ep (fun ep -> f ep acc) in
		  aux ep acc
  in aux ep
