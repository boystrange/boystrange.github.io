(* This file is part of FuSe.                                           *)
(*                                                                      *)
(* FuSe is free software: you can redistribute it and/or modify         *)
(* it under the terms of the GNU General Public License as published by *)
(* the Free Software Foundation, either version 3 of the License, or    *)
(* (at your option) any later version.                                  *)
(*                                                                      *)
(* FuSe is distributed in the hope that it will be useful,              *)
(* but WITHOUT ANY WARRANTY; without even the implied warranty of       *)
(* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        *)
(* GNU General Public License for more details.                         *)
(*                                                                      *)
(* You should have received a copy of the GNU General Public License    *)
(* along with FuSe.  If not, see <http://www.gnu.org/licenses/>.        *)
(*                                                                      *)
(* Copyright 2015-2016 Luca Padovani                                    *)

let prefix_of_seq ep =
  let a, b = Session.create () in
  let f ep' =
    let x, ep' = Session.receive ep' in
    let ep = Session.seq_select ep (fun ep -> Session.send ep x) in
    let y, ep' = Session.receive ep' in
    let ep = Session.send ep y in
    Session.close ep;
    Session.close ep'
  in
  let _ = Thread.create f a in b
             
let seq_of_prefix ep =
  let a, b = Session.create () in
  let f ep' =
    let x, ep = Session.receive ep in
    let ep' = Session.seq_branch ep' (fun ep -> Session.send ep x) in
    let y, ep = Session.receive ep in
    let ep' = Session.send ep' y in
    Session.close ep;
    Session.close ep'
  in
  let _ = Thread.create f a in b
