val shopLoop : μA.&[ Add : ?α.A, CheckOut : ?β.?γ.end ] -> α list -> unit
val shop     : μA.&[ Add : ?α.A, CheckOut : ?β.?γ.end ] Service.t -> unit
val voucher  : α -> β -> μA.⊕[ Add : !γ.A, CheckOut : !α.!β.end ] -> γ -> γ
val mother   : α -> β
	       -> &[ Add : ?γ.μA.&[ Add : ?δ.A, CheckOut : ?α.?β.end ] ] Service.t
	       -> ?(δ -> δ).!ε.end Service.t -> γ -> unit
val son      : ?(α -> β).!β.end Service.t -> α -> unit
				    
