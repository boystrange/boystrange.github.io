
let a, b = Session.create ()

let _ = Session.close (Session.send a b)
