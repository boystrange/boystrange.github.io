# Revision history for EasyJoin

## 1.0 -- 2019-01-10

* First version. Released on an unsuspecting world.
