{-
┌───────────────────────────────────────────────────────────────────╖
│ This file is part of MC².                                         ║
│                                                                   ║
│ MC² is free software: you can redistribute it and/or modify it    ║
│ under the terms of the GNU General Public License as published by ║
│ the Free Software Foundation, either version 3 of the License, or ║
│ (at your option) any later version.                               ║
│                                                                   ║
│ MC² is distributed in the hope that it will be useful, but        ║
│ WITHOUT ANY WARRANTY; without even the implied warranty of        ║
│ MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU ║
│ General Public License for more details.                          ║
│                                                                   ║
│ You should have received a copy of the GNU General Public License ║
│ along with MC². If not, see <http://www.gnu.org/licenses/>.       ║
│                                                                   ║
│ Copyright 2018 Luca Padovani                                      ║
╘═══════════════════════════════════════════════════════════════════╝
-}

module MultiSet where

import qualified Data.Map.Strict as M

type MultiSet a = M.Map a Int

empty :: MultiSet a
empty = M.empty

singleton :: a -> MultiSet a
singleton x = M.singleton x 1

union :: Ord a => MultiSet a -> MultiSet a -> MultiSet a
union = M.unionWith (+)

occur :: Ord a => a -> MultiSet a -> Int
occur = M.findWithDefault 0
